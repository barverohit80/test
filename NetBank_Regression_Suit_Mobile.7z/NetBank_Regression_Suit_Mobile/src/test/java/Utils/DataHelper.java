package Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

public class DataHelper {

	private static Workbook workbook;

	public static HashMap<String, String> readData(String filePath,
			String sheetName, String caseName) {
		HashMap<String, String> data = null;
		try {

			File file = new File(filePath);

			FileInputStream fs = new FileInputStream(file);
			Sheet sheet = null;
			if (filePath.contains(".xlsx")) {
				workbook = new XSSFWorkbook(fs);
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).contentEquals(sheetName)) {
						sheet = (XSSFSheet) workbook.getSheet(sheetName);
						break;
					} else {
						if (i == workbook.getNumberOfSheets()) {
							Assert.fail("Sheet with \"" + sheetName
									+ "\" name does not exist in (" + filePath
									+ ")..!!");
						}
					}
				}
			} else if (filePath.contains(".xls")) {
				workbook = new HSSFWorkbook(fs);
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).contentEquals(sheetName)) {
						sheet = (HSSFSheet) workbook.getSheet(sheetName);
						break;
					} else {
						if (i == workbook.getNumberOfSheets()) {
							Assert.fail("Sheet with \"" + sheetName
									+ "\" name does not exist in (" + filePath
									+ ")..!!");
						}
					}
				}
			}
			Row HeaderRow = sheet.getRow(1);
			// System.out.println(sheet.getPhysicalNumberOfRows());
			loop: for (int i = 2; i <= sheet.getPhysicalNumberOfRows(); i++) {
				Row currentRow = sheet.getRow(i);
				String casesName = currentRow.getCell(0).getStringCellValue();
				if (casesName.equals(caseName)) {
					data = new HashMap<String, String>();
					// System.out.println(HeaderRow.getPhysicalNumberOfCells());
					for (int j = 1; j < HeaderRow.getPhysicalNumberOfCells(); j++) {
						Cell currentCell = currentRow.getCell(j,
								Row.RETURN_NULL_AND_BLANK);
						if (currentCell == null) {
							if (!(HeaderRow.getCell(j,
									Row.RETURN_NULL_AND_BLANK) == null)) {
								data.put(HeaderRow.getCell(j)
										.getStringCellValue(), "");
							}
						} else if ("".equals(currentCell.getStringCellValue()
								.trim())) {
							if (!HeaderRow
									.getCell(j, Row.RETURN_NULL_AND_BLANK)
									.equals("")) {
								data.put(HeaderRow.getCell(j)
										.getStringCellValue(), "");
							}
						}

						else
							data.put(HeaderRow.getCell(j).getStringCellValue(),
									currentCell.getStringCellValue());
					}
					// System.out.println("currentHash "
					// + data.get("Limit_Increase").substring(0, 15));
					break loop;
				}
			}
			fs.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Assert.fail("file not found please provide the correct path.. "
					+ "==> " + filePath);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Specified Data is not available or Might me numeric in the excel (Add single quote for numeric data in excel)");
		}
		// System.out.println(data);
		return data;
	}

	public static void main(String[] args) {
		// DataHelper.readData("SuplimentryCard", "Case1");
		// HashMap<String, String> readDataFromExportFile = new HashMap<String,
		// String>();
		// readDataFromExportFile = DataHelper
		// .readData(
		// "C:/Selenium/eclipse/NetBank_Regression_Suit/src/test/resources/testData/TestData-Sweden.xlsx",
		// "Export", "Transaction");

		// System.out.println(DataHelper.readData(
		// "C:/Selenium/eclipse/NetBank_Regression_Suit/src/test/resources/testData/Products.xlsx",
		// "Norway",
		// "re:member Visa Gold"));
		// List<Transaction_GetSet> expected = DataHelper
		// .readFAQDATA(
		// "D:/eclipse/NetBank_Regression_Suit/src/test/resources/testData/FAQ's_NO.xlsx",
		// "Remember");
		// for (Transaction_GetSet t : expected) {
		// System.out.println(t.getType());
		// System.out.println(t.getIndex());
		// System.out.println(t.getQuestion());
		// System.out.println(t.getAnswer());
		// }
		// System.out
		// .println(DataHelper
		// .readFAQDATA(
		// "D:/eclipse/NetBank_Regression_Suit/src/test/resources/testData/FAQ's_NO.xlsx",
		// "Remember"));

		// System.out
		// .println(DataHelper
		// .readData(
		// "D:/eclipse/NetBank_Regression_Suit/src/test/resources/testData/Insurances Darwin v1.13_Sweden.xlsx",
		// "remember", "Description short").get(
		// "Aktivitetsskydd"));

		System.out
				.println(DataHelper
						.readData(
								"D:/eclipse/NetBank_Regression_Suit/src/test/resources/testData/Insurances Darwin v1.13_Sweden.xlsx",
								"insurance headers", "Header").get(
								"re:member (MasterCard, Visa and Unicef)"));

	}

}
