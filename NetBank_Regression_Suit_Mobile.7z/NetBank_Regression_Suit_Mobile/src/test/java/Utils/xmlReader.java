package Utils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.junit.Assert;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class xmlReader {
	// public static String LANGUAGE;

	public static HashMap<String, String> readXMLTagValueByNameAttribute(
			int languageCode) throws FileNotFoundException, IOException,
			ParserConfigurationException, SAXException,
			XPathExpressionException {
		HashMap<String, String> values = new HashMap<String, String>();

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = null;
		switch (languageCode) {
		case _Constants.norway:
			doc = builder.parse("src\\test\\resources\\Labels\\strings-NO.xml");
			break;

		case _Constants.sweden:
			doc = builder.parse("src\\test\\resources\\Labels\\strings-SE.xml");
			break;

		case _Constants.denmark:
			doc = builder.parse("src\\test\\resources\\Labels\\strings-dk.xml");
			break;

		case _Constants.english:
			doc = builder.parse("src\\test\\resources\\Labels\\strings-EN.xml");
			break;

		default:
			Assert.fail("No Such language available");
		}
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		// XPathExpression expr = xpath.compile("/resources/string[@name='"
		// + attributeValue + "']");
		XPathExpression expr;
		XPathExpression expr1;

		XPathExpression xpr = xpath.compile("count(/resources/string)");
		Double d = new Double((Double) xpr.evaluate(doc, XPathConstants.NUMBER));
		int nodes = d.intValue();
		for (int i = 0; i <= nodes; i++) {
			expr = xpath.compile("/resources/string[" + i + "]");
			expr1 = xpath.compile("/resources/string[" + i + "]/@name");
			values.put(expr1.evaluate(doc, XPathConstants.STRING) + "",
					expr.evaluate(doc, XPathConstants.STRING) + "");
		}

		return values;
		// System.out.println(values.size());
	}

	public static void main(String[] args) throws FileNotFoundException,
			XPathExpressionException, IOException,
			ParserConfigurationException, SAXException {
		// xmlReader.LANGUAGE = "Norway";
		readXMLTagValueByNameAttribute(1);
	}
}
