package Utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;

public class configReader extends Properties {

	private static final long serialVersionUID = 1L;
	private static Properties PROPERTIES = new Properties();
	private static Properties PRODUCT_PROPERTIES;

	public configReader() {
		try {
			PROPERTIES.load(new FileInputStream("Config/config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public configReader(int region, String product) {
		try {
			PRODUCT_PROPERTIES = new Properties();
			switch (region) {
			case _Constants.norway:
				if (_Constants.REMEMBER.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/no_remember.properties"));
				else if (_Constants.BBL.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/no_bbl.properties"));
				break;

			case _Constants.sweden:
				if (_Constants.REMEMBER.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/se_remember.properties"));
				else if (_Constants.MORE_GOLF.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/se_moregolf.properties"));
				else if (_Constants.MERVARDE.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/se_mervarde.properties"));
				break;

			case _Constants.denmark:
				if (_Constants.REMEMBER.equals(product))
					PRODUCT_PROPERTIES.load(new FileInputStream(
							"Config/dk_remember.properties"));
				break;

			default:
				Assert.fail("No Such Region available");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Configuration specific properties

	public final String getScreenShot() {
		return PROPERTIES.getProperty("SCREENSHOTS");
	}

	public final String getBROWSER() {
		return PROPERTIES.getProperty("BROWSER");
	}

	public final String getPLATFORM() {
		return PROPERTIES.getProperty("PLATFORM");
	}

	public final String getFULL_RESET() {
		return PROPERTIES.getProperty("FULL_RESET");
	}

	public final String getNO_RESET() {
		return PROPERTIES.getProperty("NO_RESET");
	}

	public final String getAPP_ACTIVITY() {
		return PROPERTIES.getProperty("APP_ACTIVITY");
	}

	/*
	 * Produc specific required properties
	 */

	public final String getAPK() {
		return PRODUCT_PROPERTIES.getProperty("APK");
	}

	public final String getAPP_PACKAGE() {
		return PRODUCT_PROPERTIES.getProperty("APP_PACKAGE");
	}

	public final String getUSERNAME() {
		return PRODUCT_PROPERTIES.getProperty("USERNAME");
	}

	public final String getPASSWORD() {
		return PRODUCT_PROPERTIES.getProperty("PASSWORD");
	}

	public final String getOTP_PWD() {
		return PRODUCT_PROPERTIES.getProperty("OTP_PWD");
	}

	public final String getPIN_CODE() {
		return PRODUCT_PROPERTIES.getProperty("PIN_CODE");
	}

	public final String getCONTACT_NO() {
		return PRODUCT_PROPERTIES.getProperty("CONTACT_NO");
	}

	public final String getOTP_LINK() {
		return PRODUCT_PROPERTIES.getProperty("OTP_LINK");
	}

	public static void main(String[] args) {
		configReader nrc = new configReader(1, "remember");
		System.out.println(nrc.getPIN_CODE());
	}
}
