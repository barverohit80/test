package Utils;

import java.io.IOException;
import java.net.ServerSocket;

public class Start_Stop_AppiumServer {

	// private AppiumDriverLocalService service;
	// private AppiumServiceBuilder builder;
	// private DesiredCapabilities cap;
	//
	// public void startServer(int port, String udid) {
	// // Set Capabilities
	// cap = new DesiredCapabilities();
	// cap.setCapability("noReset", "false");
	//
	// // Build the Appium service
	// builder = new AppiumServiceBuilder();
	// builder.withIPAddress("127.0.0.1");
	// builder.usingPort(port);
	// cap.setCapability("udid", udid);
	// builder.withCapabilities(cap);
	// builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
	// builder.withArgument(GeneralServerFlag.LOG_LEVEL, "error");
	//
	// // Start the server with the builder
	// service = AppiumDriverLocalService.buildService(builder);
	// service.start();
	// }

	// public void stopServer_() {
	// service.stop();
	// }

	public static void startServer(String ip, int port, String UDID) {
		Runtime runtime = Runtime.getRuntime();
		try {
			if (!checkIfServerIsRunnning(port)) {
				runtime.exec("cmd.exe /c start cmd.exe /k \"appium -a " + ip
						+ " --session-override -p " + port + " -bp "
						+ (new Integer(port) + 2) + " -U " + UDID + "\"");

				Thread.sleep(25000);
			} else {
				System.out.println(port + " port is used ");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void stopServer() {
		Runtime runtime = Runtime.getRuntime();
		try {
			runtime.exec("taskkill /F /IM node.exe");
			runtime.exec("taskkill /F /IM cmd.exe");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean checkIfServerIsRunnning(int port) {

		boolean isServerRunning = false;
		ServerSocket serverSocket;
		try {
			serverSocket = new ServerSocket(port);
			serverSocket.close();
		} catch (IOException e) {
			// If control comes here, then it means that the port is in use
			isServerRunning = true;
		} finally {
			serverSocket = null;
		}
		return isServerRunning;
	}

	public static void main(String[] args) throws Exception {

		// Start_Stop_AppiumServer appiumServer = new Start_Stop_AppiumServer();
		Start_Stop_AppiumServer.stopServer();
		System.out.println(Start_Stop_AppiumServer
				.checkIfServerIsRunnning(4723));
		Start_Stop_AppiumServer.startServer("127.0.0.1", 4723, "ZX1G428JBS");
		System.out.println(Start_Stop_AppiumServer
				.checkIfServerIsRunnning(4723));
		// Start_Stop_AppiumServer.startServer(4723, "ZX1G428JBS");

		// appiumServer.stopServer();
	}
}
