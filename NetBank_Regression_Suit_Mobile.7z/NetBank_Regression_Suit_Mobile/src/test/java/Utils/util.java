package Utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Pattern;

import org.apache.commons.validator.routines.BigDecimalValidator;
import org.apache.commons.validator.routines.CurrencyValidator;
import org.testng.Assert;

public class util {
	Date referenceDate;

	public String getOldDate(int noOfYears, int noOfMonths, int noOfDays) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-M-d");

		referenceDate = new Date();
		Calendar c = Calendar.getInstance();
		if (c.getActualMaximum(Calendar.DAY_OF_MONTH) == 28
				|| c.getActualMaximum(Calendar.DAY_OF_MONTH) == 29
				|| c.getActualMaximum(Calendar.DAY_OF_MONTH) == 30
				|| c.getActualMaximum(Calendar.DAY_OF_MONTH) == 31) {
			c.setTime(referenceDate);
			c.add(Calendar.YEAR, -noOfYears);
			c.add(Calendar.MONTH, -noOfMonths);
			c.add(Calendar.DATE, -noOfDays + 1);
		} else {
			c.setTime(referenceDate);
			c.add(Calendar.YEAR, -noOfYears);
			c.add(Calendar.MONTH, -noOfMonths);
			c.add(Calendar.DATE, -noOfDays);
		}
		// System.out.println(dateFormat.format(c.getTime()));
		return dateFormat.format(c.getTime()) + "";
	}

	public static String dateAndTime(String format) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}

	public static String AmountFormat(String Amount, String Language,
			String Country) {
		Double currencyAmount = null;
		NumberFormat currencyFormatter = null;
		String formatedAmount = null;
		try {
			currencyAmount = new Double(Amount);
			Locale locale = new Locale(Language, Country);
			currencyFormatter = NumberFormat.getCurrencyInstance(locale);
			formatedAmount = currencyFormatter.format(currencyAmount) + "";
			if (Country.equals(_Constants.COUNTRY[3])) {
				formatedAmount = currencyFormatter.format(currencyAmount)
						.replaceAll("[kr ]", "") + " kr.";
			}
			// Currency currentCurrency = Currency.getInstance(locale);
			// System.out.println(locale.getDisplayName()
			// + ", "
			// + currentCurrency.getDisplayName()
			// + ": "
			// + currencyFormatter.format(currencyAmount).replaceAll(
			// "[$kr  kr]", ""));
		} catch (Exception e) {
			Assert.fail("Something is wrong eigther with country code or amount ");
		}
		return formatedAmount;
		// return
		// currencyFormatter.format(currencyAmount).replaceAll("[$kr  kr]",
		// "")
		// + "";
	}

	public static Boolean validateAmountFormat(String currenySign,
			String amount, String language, String country) {
		BigDecimalValidator validator = CurrencyValidator.getInstance();
		Locale locale = new Locale(language, country);
		String formattedAmount;
		BigDecimal value = null;
		boolean boo = false;
		if (country.equals(_Constants.COUNTRY[1])) {
			formattedAmount = currenySign + " " + amount;
			value = validator.validate(formattedAmount, locale);
			boo = value != null;
		} else if (country.equals(_Constants.COUNTRY[2])) {
			formattedAmount = amount + " " + currenySign;
			value = validator.validate(formattedAmount, locale);
			boo = value != null;
		} else if (country.equals(_Constants.COUNTRY[3])) {
			formattedAmount = amount + " " + currenySign;
			Pattern p = Pattern
					.compile("^-?(\\d{1,3}(\\.\\d{3})*|(\\d+))(\\,\\d{2})?(\\s+kr\\.)$");
			boo = (p.matcher(formattedAmount).matches() || formattedAmount
					.equals(""));
		}

		// String[] amtWithoutFormat = null;
		// String normalValue = null, formatedValue = null, expectedAmount =
		// null;
		// boolean boo = false;
		// int size;
		// if (amount.contains(",")) {
		// amtWithoutFormat = amount.split(",");
		// normalValue = amtWithoutFormat[0].trim().replaceAll("[\\s\u00a0.]",
		// "");
		// size = AmountFormat(normalValue, language, country).length();
		// formatedValue = AmountFormat(normalValue, language, country)
		// .substring(0, size - 3).replaceAll(" ", "[\\s\u00a0]");
		// expectedAmount = formatedValue + "," + amtWithoutFormat[1];
		// boo = expectedAmount.equals(amount);
		// } else {
		// size = AmountFormat(normalValue, language, country).length();
		// normalValue = amount.trim().replaceAll("[\\s\u00a0.]", "");
		// formatedValue = AmountFormat(normalValue, language, country)
		// .substring(0, size - 3).replaceAll(" ", "[\\s\u00a0]");
		// boo = formatedValue.equals(amount);
		// }
		System.out.println(value);
		return boo;

	}

	public static boolean validateJavaDate(String strDate, String dateFormat) {
		/* Check if date is 'null' */
		if (strDate.trim().equals("")) {
			Assert.fail("Date is not present");
			return true;
		}
		/* Date is not 'null' */
		else {
			/*
			 * Set preferred date format, For example MM-dd-yyyy,
			 * MM.dd.yyyy,dd.MM.yyyy etc.
			 */
			SimpleDateFormat sdfrmt = new SimpleDateFormat(dateFormat);
			sdfrmt.setLenient(false);
			/*
			 * Create Date object parse the string into date
			 */
			try {
				// Date javaDate =
				sdfrmt.parse(strDate);
				// System.out.println(strDate + " is valid date format");
			}
			/* Date format is invalid */
			catch (ParseException e) {
				System.out.println(strDate + " is Invalid Date format");
				return false;
			}
			/* Return true if date format is valid */
			return true;
		}
	}

	public static String onlyDigitsArePresent(HashMap<String, String> data,
			String fieldName) {
		Pattern p = Pattern.compile("^[0-9]+$");
		String field = data.get(fieldName);
		field = field.replaceAll("[^\\d.]", "");
		Assert.assertTrue(p.matcher(field).matches() || field.equals(""),
				"Customer should be able to enter only Digits in textBox");
		return field;
	}

	public static String truncateString(String str, String length) {

		if (str.length() > new Integer(length)) {
			return str.substring(0, new Integer(length));
		} else {
			return str;
		}
	}

	public static boolean isAmountFormatCorrect(HashMap<String, String> data,
			String fieldName) {
		Pattern p = Pattern.compile("\\d+([,.]\\d{1,10})?");
		String field = data.get(fieldName);

		System.out.println(p.matcher(field).matches());
		return p.matcher(field).matches();
	}

	public static void enterTextByADBShell(String device, String TextToEnter) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String typeText = "adb -s " + device + " shell input text \""
				+ TextToEnter + "\"";
		try {
			Runtime.getRuntime().exec(typeText);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws ParseException {
		// util.temp();
		// System.out.println(util.dateAndTime("dd.MM.yyyy"));
		// System.out.println(util.dateAndTime("yy_MM_dd"));
		// util util = new util();
		// String[] arr = util.getOldDate(0, 3, 0).split("-");
		// System.out.println(arr[0]);
		// System.out.println(arr[1]);
		// System.out.println(arr[2]);
		System.out.println(util.AmountFormat("2344343", "en", "US"));
		System.out.println(util.AmountFormat("23343443.43", "nb", "NO"));
		System.out.println(util.AmountFormat("1213133.3", "da", "DK"));
		System.out.println(util.AmountFormat("1213133.3233", "sv", "SE"));

//		System.out.println(validateAmountFormat("kr.", "-1.213.133,30", "da",
//				"DK"));
		

		// assertNotNull(amount);
		// System.out.println();
		// System.out.println(util.validateAmountFormat("234 439 933,09", "no",
		// "NO"));
		// System.out
		// .println(util.validateAmountFormat("234 439 933", "no", "NO"));
		//
		// System.out.println(util.validateJavaDate("30.04", "dd.MM"));
		// System.out.println(util.validateJavaDate("30/04", "dd.MM"));
	}

}
