package Utils;

import java.util.ArrayList;
import java.util.Arrays;

public class temp {

	public static void main(String[] args) {

		String str = "Rohit is ohirt but no he is not on bed";
		String[] temp = str.split("\\s");
		for (int i = 0; i < temp.length; i++) {
			char[] str2 = temp[i].toLowerCase().toCharArray();
			for (int j = i+1; j < temp.length; j++) {
				if (temp[i].length() == temp[j].length()) {
					char[] str3 = temp[j].toLowerCase().toCharArray();
					Arrays.sort(str2);
					Arrays.sort(str3);
					if (Arrays.equals(str2, str3))
						System.out.print("[" + temp[i] + "," + temp[j] + "], ");
				}
			}
		}

		int[] array = { 5, 7, 11, 45, 76, 2, 0, 8, 13, 3 };
		boolean isPrime;
		ArrayList<Integer> index = new ArrayList<Integer>();

		for (int i = 0; i < array.length; i++) {
			isPrime = true;
			if (!(array[i] == 0)) {
				loop: for (int j = 2; j < array[i]; j++) {
					if (array[i] % j == 0) {
						isPrime = false;
						break loop;
					}
				}
				if (isPrime) {
					// System.out.println(array[i] + "is prime ");
					index.add(i);

				}
			}
		}
		for (int i = 0; i < index.size(); i++) {
			int min = array[index.get(i)];
			for (int j = i + 1; j < index.size(); j++) {
				if (min > array[index.get(j)]) {
					min = array[index.get(j)];
					array[index.get(i)] = array[index.get(j)]
							+ array[index.get(i)];
					array[index.get(j)] = array[index.get(i)]
							- array[index.get(j)];
					array[index.get(i)] = array[index.get(i)]
							- array[index.get(j)];
				}
			}
		}
		System.out.println();
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + ", ");
		}
		// System.out.println(index);
	}
}
