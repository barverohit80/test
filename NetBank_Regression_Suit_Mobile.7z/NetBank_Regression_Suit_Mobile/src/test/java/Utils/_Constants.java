package Utils;

import java.util.HashMap;

import seleniumCore.SharedDriver;

public class _Constants {

	public static HashMap<String, String> labels = SharedDriver.labels;

	public static final String NORWAY = "NORWAY";
	public static final String SWEDEN = "SWEDEN";
	public static final String DENMARK = "DENMARK";
	public static final String ENGLISH = "ENGLISH";
	public static final int norway = 1;
	public static final int sweden = 2;
	public static final int denmark = 3;
	public static final int english = 0;
	public static final String ENCRYPTED_PERSONAL_PASSWORD = "��������";
	public static String[] LANGUAGE = { "en", "nb", "sv", "da" };
	public static String[] COUNTRY = { "US", "NO", "SE", "DK" };
	public static String[] MONTHS = { "", labels.get("JANUARY"),
			labels.get("FEBRUARY"), labels.get("MARCH"), labels.get("APRIL"),
			labels.get("MAY"), labels.get("JUNE"), labels.get("JULY"),
			labels.get("AUGUST"), labels.get("SEPTEMBER"),
			labels.get("OCTOBER"), labels.get("NOVEMBER"),
			labels.get("DECEMBER") };

	public static int dummyAxis = 50;
	public final static int CARD_LENGTH = 16;

	public static String[] NORWAY_EMPLOYMENT_TYPE = { "Fast ansatt",
			"Midlertidig ansatt", "Selvstendig n�ringsdrivende", "Vikar",
			"Arbeidsledig", "Student" };

	public static String[] DENMARK_HOUSING_TYPE = { "Hjemmeboende",
			"Lejebolig", "Ejerbolig", "Andelsbolig", "Andet" };

	public static String[] SWEDEN_EMPLOYMENT_TYPE = { "Anst�lld",
			"Egen r�relse", "Arbetsl�s", "Studerande", "Pension�r" };
	public static String[] SWEDEN_HOUSING_TYPE = { "Hyresr�tt", "Inneboende",
			"Bostadsr�tt", "Egen fastighet" };

	public final static String APPLIED_CREDIT_AMOUNT = "5000";
	public final static String ADULT_COUNT = "1";
	public final static String CHILD_COUNT = "0";

	public final static String REMEMBER = "remember";
	public final static String MORE_GOLF = "moregolf";
	public final static String MERVARDE = "mervarde";
	public final static String BBL = "bbl";
	public final static String COOP_MC = "coop mastercard";
	public final static String FORMED_LEMMER = "formedlemmer ";
	public final static String COOP_VISA = "coop visa";
	public final static String EC_PLATINUM = "ec platinum";

	public static void main(String[] args) {
		System.out.println(NORWAY);
	}
}
