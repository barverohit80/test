package step_definitions;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import seleniumCore.SharedDriver;
import seleniumCore.UIActionHelper;
import seleniumCore.report;
import Utils._Constants;
import Utils.util;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {
	private static String folder;
	private static Scenario scenario;
	private static int i = 0;

	@Before
	public void setUp(Scenario scenario) {
		Hooks.scenario = scenario;
		folder = scenario.getName().replace(" ", "_");
		new report();
	}

	@After
	public static void AttachScreenshot() {
		try {
			if (SharedDriver.configreader.getScreenShot().equals("true")) {

				File src = ((TakesScreenshot) new UIActionHelper()
						.getWebDriver()).getScreenshotAs(OutputType.FILE);
				String screenShot = util.dateAndTime("yyyy_MM_dd_HH_mm_ss_S")
						+ ".jpeg";
				FileUtils.copyFile(src, new File(
						"target/cucumber-html-report_screenShots/"
								+ _Constants.COUNTRY[SharedDriver.regionCode]
								+ "/" + folder + "/" + screenShot));

				String newFileNamePath = "<a id=\"lol"
						+ i
						+ "\" class=\"passed\" onclick=\"var im=document.getElementById('topo"
						+ i
						+ "'); "
						+ "var imgStack=document.querySelectorAll('[id*=\\\'topo\\\']'); for(var i=0; i<imgStack.length; i++) { if(imgStack[i].id!=='topo'+this.id.match(/[0-9]+/)) imgStack[i].style.display='none'  }; im.style.display = (im.style.display == 'none' ? 'block' : 'none');\">"
						+ "<b>screenshot</b>"
						+ "</a>"
						+ "  <img id=\"topo"
						+ i
						+ "\" style=\"display: none;\" height=\"736\" width=\"435\""
						+ "src=\"file:///" + System.getProperty("user.dir")
						+ "/target/cucumber-html-report_screenShots/"
						+ _Constants.COUNTRY[SharedDriver.regionCode] + "/"
						+ folder + "/" + screenShot + "\"/></br>";
				scenario.write(newFileNamePath);
				i++;
			}
		} catch (WebDriverException somePlatformsDontSupportScreenshots) {
			System.err
					.println(somePlatformsDontSupportScreenshots.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
