package step_definitions;

import helpers.SignIn_helper;

import java.io.FileNotFoundException;
import java.io.IOException;

import pageobjects.SignIn_pageobject;
import seleniumCore.SharedDriver;
import seleniumCore.UIActionHelper;
import Utils.configReader;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignIn_stepdefinations {

	public static SignIn_helper signInhelper;
	public static configReader regionProperty;
	public static SignIn_pageobject signInPageObject;

	public SignIn_stepdefinations(SharedDriver driver)
			throws FileNotFoundException, IOException {
		signInhelper = new SignIn_helper(new UIActionHelper(driver.getDriver()));
		signInPageObject = new SignIn_pageobject();
	}

	@Given("^Launch the NetBank app$")
	public void launch_the_NetBank_app() throws Throwable {
		System.out.println("App Launched...!!");
		signInhelper.allowAppPermission();
		signInhelper.allowAppPermission();
		// new Hooks().embedScreenshot(Hooks.scenario);
	}

	@Then("^User validate the Signicat Main Page$")
	public void User_validate_the_Signicat_Main_Page() {
		signInhelper.validateSignicatMainPage();
	}

	@When("^User Clicks on bankID button$")
	public void User_Clicks_on_bank_id_button() {
		signInhelper.clickOnBankIDButton();
	}

	@When("^User Clicks on Create Pin button$")
	public void User_Clicks_on_Create_Pin_button() {
		signInhelper.clickOnCreatePinButton();
	}

	@When("^User Clicks on Log in button$")
	public void User_Clicks_on_Log_In_button() {
		signInhelper.clickOnLogInButton();
	}

	@When("^User Clicks on OK button$")
	public void User_Clicks_on_OK_button() {
		signInhelper.clickOnOKButton();
	}

	@Then("^User navigates to Singnicat Login page$")
	public void User_navigates_to_Singnicat_Login_page() {
		signInhelper.validateUserIsOnSignicatPage();
	}

	@When("^User enter the SSN$")
	public void User_enter_the_SSN() throws InterruptedException {
		signInhelper.enterSSN();
	}

	@And("^Click on next button$")
	public void User_Clicks_on_next_button() throws InterruptedException {
		signInhelper.clickOnNextArrow();
	}

	@And("^User Clicks on Cancel button$")
	public void User_Clicks_on_Cancel_button() throws InterruptedException {
		signInhelper.clickOnCancelButton();
	}

	@When("^User enter OTP$")
	public void User_enter_OTP() throws InterruptedException {
		signInhelper.enterOTP();
	}

	@When("^User enter Password$")
	public void User_enter_Password() throws InterruptedException {
		// signInhelper.EnterPassword1();
		signInhelper.enterPassword();
	}

	@When("^User clicks on \"(.*?)\" button$")
	public void user_click_on_button(String buttonText) throws Throwable {
		signInhelper.clickOnButton(buttonText);
		// new Hooks().embedScreenshot(Hooks.scenario);
	}

	@When("^User clicks on \"(.*?)\" label$")
	public void user_clicks_on_label(String labelText) throws Throwable {
		signInhelper.clickOnTab(labelText);
	}

	@When("^User clicks on \"(.*?)\" tab$")
	public void user_click_on_tab(String tabText) throws Throwable {
		signInhelper.clickOnTab(tabText);
		// new Hooks().embedScreenshot(Hooks.scenario);
	}

	@When("^User navigate to create_your_pin_code page$")
	public void user_navigate_to_create_your_pin_code_page() {
		signInhelper.verifyUserIsOnCreatePinPage();
	}

	@And("^\"(.*?)\" popup will appear$")
	public void PopUP_will_appear(String PopupTitle) {
		signInhelper.verifyCreatePinPopupIsAppeared(PopupTitle);
	}

	@Then("^Enter the new PIN Code$")
	public void Enter_the_new_PIN_Code() throws InterruptedException {
		signInhelper.enterNewPinCode();
	}

	@When("^User Enter the PIN Code$")
	public void user_enter_the_PIN_Code() throws InterruptedException {
		signInhelper.enterPinCodeOneByOne();
	}

	@Then("^User should successfully land on NetBank HomePage$")
	public void user_should_successfully_land_on_NetBank_Homepage()
			throws InterruptedException {
		signInhelper.verifyUserIsOnNetBankHomePage();
	}

	@Then("^User navigate to customer_service page$")
	public void User_navigate_to_customer_service_page() {
		signInhelper.navigateToCustomerServicePage();
	}

	@And("^Validate the contact us information$")
	public void Validate_the_contact_us_information() {
		signInhelper.validateContactUsInfo();
	}

	@When("^User navigate to enter_pin_code page$")
	public void User_navigate_to_enter_pin_code_page() {
		signInhelper.navigateToEnterPinCodePage();
	}

	@And("^Validate the create pin pop up$")
	public void Validate_the_create_pin_pop_up() {
		signInhelper.validateCreatePinPopUp();
	}

	/*
	 * Sweden
	 */

	@Then("^User selects the BankID and enters the Security Code$")
	public void User_selects_the_BankID_and_enters_the_Security_Code() {
		signInhelper.selectBankIDandEnterSecurityCode();
	}

	/*
	 * Denmark
	 */

	@Then("^User validate the Signicat Main Page for Denmark$")
	public void User_validate_the_Signicat_Main_Page_for_Denmark() {
		signInhelper.validateSignicatMainPage_forDenmark();
	}

	@Then("^User navigates to Denmark Singnicat Login page$")
	public void User_navigates_to_Denmark_Singnicat_Login_page() {
		signInhelper.validateUserIsOnDenmarkSignicatPage();
	}

	@When("^User enter the NemID$")
	public void User_enter_the_NemID() throws InterruptedException {
		signInhelper.enterNemID();
	}

	@And("^User enter Passcode$")
	public void User_enter_Passcode() throws InterruptedException {
		signInhelper.enterPasscode();
	}

	@Then("^User copy the code and search for the OTP$")
	public void User_copy_the_code_and_search_for_the_OTP() {
		signInhelper.copyCodeAndSearchForOTP();
	}

	@And("^User enter the OTP$")
	public void User_enter_the_OTP() {
		signInhelper.enterSearchedOTP();
	}
	
	@When("^User enter the Password$")
	public void user_enter_the_Password() throws InterruptedException {
		signInhelper.enterThePassword();
	}

	@Then("^Press Enter button$")
	public void Press_Enter_button() throws InterruptedException {
		signInhelper.pressEnterButton();
	}
}
