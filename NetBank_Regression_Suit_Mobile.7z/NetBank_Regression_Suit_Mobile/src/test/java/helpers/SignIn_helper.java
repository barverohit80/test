package helpers;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import pageobjects.SignIn_pageobject;
import seleniumCore.SharedDriver;
import seleniumCore.UIActionHelper;
import seleniumCore.WaitTime;
import seleniumCore.report;
import Utils._Constants;
import Utils.configReader;
import Utils.util;

public class SignIn_helper {
	private static UIActionHelper uiActionHelper = null;
	private static configReader configReader;
	private static HashMap<String, String> labels;
	private static String num = "5887", otp;

	public SignIn_helper() {

	}

	public SignIn_helper(UIActionHelper uiActionHelper)
			throws FileNotFoundException, IOException {
		SignIn_helper.uiActionHelper = uiActionHelper;
		configReader = SharedDriver.configreader;
		SignIn_helper.labels = SharedDriver.labels;
	}

	public void allowAppPermission() throws InterruptedException {
		if (uiActionHelper.isLocatorPresent(
				By.xpath(SignIn_pageobject.ALLOW_BUITTON(labels.get("allow"))),
				WaitTime.getShortWaitTime() / 2, WaitTime.POOLINGNANOSECONDS))
			uiActionHelper.waitForXpathThenClick(
					"Click on Allow button to proceed ",
					SignIn_pageobject.ALLOW_BUITTON(labels.get("allow")));
	}

	public static void waitTillLoaderDisappears() {
		uiActionHelper.waitForElementToAppear(
				By.xpath(SignIn_pageobject.LOADER),
				"Loder should be appeared ", WaitTime.getMediunWaitTime(),
				WaitTime.POOLINGNANOSECONDS);
		System.out.println("Loader found");
		uiActionHelper.waitForElementToDisAppear(
				By.xpath(SignIn_pageobject.LOADER),
				"Loder should be disappeared ", WaitTime.getLongWaitTime(),
				WaitTime.POOLINGNANOSECONDS);
		System.out.println("Loader Disappeared");
	}

	public void validateSignicatMainPage() {
		Assert.assertEquals(labels.get("activate_app_using"), uiActionHelper
				.waitForIDAndGetText(SignIn_pageobject.SIGNICAT_HEADER),
				labels.get("activate_app_using")
						+ " text should be present on log in screen ");
		Assert.assertEquals(labels.get("bank_id"), uiActionHelper
				.waitForXPATHAndGetText(SignIn_pageobject.SIGNICAT_BANKID_BTN),
				labels.get("bank_id")
						+ " text should be present on log in screen ");
		uiActionHelper.waitForXpathAndValidateText(
				SignIn_pageobject.CREATE_YOUR_PIN_BTN,
				labels.get("bank_id_mobile"));
	}

	public void clickOnButton(String buttonName) {
		// if (!uiActionHelper
		// .isLocatorPresent(By.xpath(SignIn_pageobject.BUTTON_TEXT(labels
		// .get(buttonName))), WaitTime.getShortWaitTime()
		// / WaitTime.getShortWaitTime(),
		// WaitTime.POOLINGNANOSECONDS))
		// new Invoices_helper(uiActionHelper).scrollTopToBottom();
		report.reportPass("Take a screen shot after validating labels ", true);
		uiActionHelper
				.scrollToElement_Using_className(SignIn_pageobject.BUTTON);
		uiActionHelper.waitForXpathThenClick(
				"Click on " + labels.get(buttonName) + " button ",
				SignIn_pageobject.BUTTON_TEXT(labels.get(buttonName)));
	}

	public void clickOnTab(String viewName) {
		report.reportPass("Take a screen shot after clicking the button ", true);
		uiActionHelper.waitForXpathThenClick("Click on " + labels.get(viewName)
				+ " tab ", SignIn_pageobject.LABEL_TEXT(labels.get(viewName)));
	}

	public void emergencyContactInfoIsPresent() {
		uiActionHelper.waitForXpath("Contact info must be present ",
				SignIn_pageobject.VIEW_TEXT(configReader
						.getProperty("EMERGENY_CONTACT_INFO")));
		report.reportPass(configReader.getProperty("EMERGENY_CONTACT_INFO")
				+ " text should be present", uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject.VIEW_TEXT(configReader
						.getProperty("EMERGENY_CONTACT_INFO"))), WaitTime
				.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("Contact info must be present ",
				SignIn_pageobject.VIEW_TEXT(configReader.getCONTACT_NO()));
		report.reportPass(configReader.getCONTACT_NO()
				+ " text should be present", uiActionHelper.isLocatorPresent(
				By.xpath(SignIn_pageobject.VIEW_TEXT(configReader
						.getCONTACT_NO())), WaitTime.getShortWaitTime(),
				WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("Contact info must be present ",
				SignIn_pageobject.VIEW_TEXT(configReader.getProperty("DOT")));
		report.reportPass(configReader.getProperty("DOT")
				+ " text should be present", uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject.VIEW_TEXT(configReader
						.getProperty("DOT"))), WaitTime.getShortWaitTime(),
				WaitTime.POOLINGNANOSECONDS));
	}

	public void validateSSNLoginPage() {
		uiActionHelper.waitForXpath("BankID logo Should be present ",
				SignIn_pageobject.IMAGE_TEXT(configReader.getProperty("LOGO")));
		report.reportPass("BankID logo Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.IMAGE_TEXT(configReader.getProperty("LOGO"))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("Identifying text Should be present ",
				SignIn_pageobject.VIEW_TEXT(configReader
						.getProperty("IDENTIFYING")));
		report.reportPass("Identifying text Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.VIEW_TEXT(configReader.getProperty("IDENTIFYING"))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

		uiActionHelper
				.waitForXpath("MENU ICON Should be present ", SignIn_pageobject
						.SPINNER_TEXT(configReader.getProperty("MENU")));
		report.reportPass("MENU ICON Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.SPINNER_TEXT(configReader.getProperty("MENU"))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("DOB field label Should be present ",
				SignIn_pageobject.VIEW_TEXT(configReader.getProperty("DOB")));
		report.reportPass("DOB field label Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.VIEW_TEXT(configReader.getProperty("DOB"))), WaitTime
						.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("HELP ICON Should be present ",
				SignIn_pageobject.SPINNER_TEXT(configReader
						.getProperty("OPEN_HELP_DAILOG")));
		report.reportPass("HELP ICON Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.SPINNER_TEXT(configReader
								.getProperty("OPEN_HELP_DAILOG"))), WaitTime
						.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath("DOB field Should be present ",
				SignIn_pageobject.EDIT_TEXT(configReader.getProperty("DOB")));
		report.reportPass("DOB field Should be present ", uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject
						.EDIT_TEXT(configReader.getProperty("DOB"))), WaitTime
						.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));

		uiActionHelper
				.waitForXpath("Button Should be present ", SignIn_pageobject
						.BUTTON_TEXT(configReader.getProperty("NEXT")));
		report.reportPass("Next Button field Should be present ",
				uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
						.BUTTON_TEXT(configReader.getProperty("NEXT"))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

		uiActionHelper.waitForXpath(
				"Length Validation message Should be present ",
				SignIn_pageobject.VIEW_TEXT(configReader
						.getProperty("SSN_LENGTH")));
		report.reportPass("Length Validation message Should be present ",
				uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
						.VIEW_TEXT(configReader.getProperty("SSN_LENGTH"))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

	}

	public void validateUserIsOnSignicatPage() {
		// emergencyContactInfoIsPresent();

		uiActionHelper.waitForElementToAppear(By.xpath(SignIn_pageobject
				.VIEW_TEXT(labels.get("LOADING_BANKID_PLEASE_WAIT"))),
				labels.get("LOADING_BANKID_PLEASE_WAIT")
						+ " should be appeared ", WaitTime.getLongWaitTime(),
				WaitTime.POOLINGNANOSECONDS);
		uiActionHelper.waitForElementToDisAppear(By.xpath(SignIn_pageobject
				.VIEW_TEXT(labels.get("LOADING_BANKID_PLEASE_WAIT"))),
				labels.get("LOADING_BANKID_PLEASE_WAIT")
						+ " should be disappeaed ", WaitTime
						.getMediunWaitTime(), WaitTime.POOLINGNANOSECONDS);

		// uiActionHelper.waitForElementToDisAppear(
		// By.xpath(SignIn_pageobject.WEBVIEW),
		// " White screen should be disappeaed ",
		// WaitTime.getMediunWaitTime(), WaitTime.POOLINGNANOSECONDS);
		// validateSSNLoginPage();
	}

	public static void type_using_ADB(String str) {
		String command = "adb shell input text \"" + str + "\"";
		try {
			Runtime.getRuntime().exec(command);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void tapByADBSell(String device, int Xaxis, int Yaxis) {
		String clickOnLocation = "adb -s " + device + " shell input tap "
				+ Xaxis + " " + Yaxis;
		try {
			Runtime.getRuntime().exec(clickOnLocation);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void enterSSN() throws InterruptedException {
		report.reportPass("Take a screen shot after clicking the button ", true);
		// uiActionHelper.waitForXpathClearThenType(
		// "NemID textbox should be present then enter the text ",
		// SignIn_pageobject.EDIT_TEXT(labels.get("DOB")),
		// configReader.getUSERNAME());

		uiActionHelper.waitForXpathClearThenType(
				"NemID textbox should be present then enter the text ",
				SignIn_pageobject.EDIT_TEXT(), configReader.getUSERNAME());

		Thread.sleep(2000);

		// report.reportPass("Expected text is => " +
		// configReader.getUSERNAME(),
		// uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
		// .EDIT_TEXT(configReader.getUSERNAME())), WaitTime
		// .getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));

		report.reportPass("Expected text is => " + configReader.getUSERNAME(),
				uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
						.EDIT_TEXT(configReader.getUSERNAME())), WaitTime
						.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));
	}

	public void enterOTP() throws InterruptedException {
		report.reportPass("Take a screen shot after clicking the button ", true);
		uiActionHelper.waitForClassClearThenType(
				"OTP textbox should be present ", SignIn_pageobject.TEXTBOX,
				configReader.getOTP_PWD());

		Thread.sleep(2000);

		report.reportPass("Expected text is => " + configReader.getOTP_PWD(),
				uiActionHelper
						.waitForClassAndGetText(SignIn_pageobject.TEXTBOX)
						.equals(configReader.getOTP_PWD()));
	}

	public void enterPassword() throws InterruptedException {
		report.reportPass("Take a screen shot after clicking the button ", true);
		uiActionHelper.waitForClassClearThenType(
				"PASSWORD textbox should be present ",
				SignIn_pageobject.TEXTBOX, configReader.getPASSWORD());

		Thread.sleep(2000);

		report.reportPass("Expected text is => " + configReader.getPASSWORD(),
				uiActionHelper
						.waitForClassAndGetText(SignIn_pageobject.TEXTBOX)
						.equals(_Constants.ENCRYPTED_PERSONAL_PASSWORD));
	}

	public void clickOnNextArrow() throws InterruptedException {
		uiActionHelper.waitForXpathThenClick("Click on Next Button ",
				SignIn_pageobject.BUTTON_TEXT(labels.get("NEXT")));
		report.reportPass("Take a screen shot after clicking the button ", true);
	}

	public void verifyUserIsOnCreatePinPage() {
		waitTillLoaderDisappears();
		uiActionHelper.waitForElementToBePresent(
				By.xpath(SignIn_pageobject.CREATE_YOUR_PIN_HEADING),
				"user should be on " + labels.get("create_your_pin_code")
						+ " page", WaitTime.getLongWaitTime() * 2,
				WaitTime.POOLINGNANOSECONDS);
		uiActionHelper.waitForXpathAndValidateText(
				SignIn_pageobject.CREATE_YOUR_PIN_HEADING,
				labels.get("create_your_pin_code"));
	}

	public void verifyCreatePinPopupIsAppeared(String PopupTitle) {
		uiActionHelper.waitForClass("Pop up should be appeared ",
				SignIn_pageobject.POP_UP);
		uiActionHelper.waitForIdAndValidateText(SignIn_pageobject.ALERT_TITLE,
				labels.get(PopupTitle));
		Assert.assertEquals(
				uiActionHelper
						.waitForIDAndGetText(SignIn_pageobject.CANCEL_BTN),
				labels.get("CANCEL"),

				"Expected-> "
						+ labels.get("CANCEL")
						+ " Actual-> "
						+ uiActionHelper
								.waitForIDAndGetText(SignIn_pageobject.CANCEL_BTN)
						+ " text is not matching");
	}

	public void enterNewPinCode() throws InterruptedException {
		System.out.println(configReader.getPIN_CODE());
		uiActionHelper.waitForXpathClearThenType("Enter the pin code ",
				SignIn_pageobject.CREATE_YOUR_PIN_TEXT,
				configReader.getPIN_CODE());

		// Thread.sleep(2000);

		report.reportPass("Entered pin Code should be correct ", uiActionHelper
				.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_TEXT)
				.equals(configReader.getPIN_CODE()));
	}

	public void enterPinCodeOneByOne() {

		uiActionHelper.waitForXpath("Waitfor Pin text box",
				SignIn_pageobject.ENTER_PIN1_TXT);
		// uiActionHelper.waitForIdClearThenType("Enter the pin code ",
		// SignIn_pageobject.ENTER_PIN1_TXT,
		// configReader.getProperty("PIN_CODE"));
		System.out.println(configReader.getPIN_CODE());
		util.enterTextByADBShell(SharedDriver.UDID, configReader.getPIN_CODE());
		report.reportPass("Take a screen shot after clicking the button ", true);
		// waitTillLoaderDisappears();
	}

	public void verifyUserIsOnNetBankHomePage() throws InterruptedException {
		report.reportPass(
				"User should be on " + labels.get("tab_title_transaction")
						+ " Page",
				uiActionHelper.isLocatorPresent(
						By.xpath(SignIn_pageobject.LABEL_TEXT(labels
								.get("tab_title_transaction"))),
						WaitTime.getLongWaitTime() + WaitTime.getLongWaitTime(),
						WaitTime.POOLINGNANOSECONDS));

	}

	public void clickOnBankIDButton() {
		uiActionHelper.waitForXpathThenClick("Click on bankID button",
				SignIn_pageobject.SIGNICAT_BANKID_BTN);
		report.reportPass("Take a screen shot after clicking the button ", true);
	}

	public void clickOnCreatePinButton() {
		uiActionHelper.waitForXpathThenClick("Click on create pin button",
				SignIn_pageobject.CREATE_YOUR_PIN_BTN);
		report.reportPass("Take a screen shot after clicking the button ", true);
	}

	public void clickOnOKButton() {
		uiActionHelper.waitForIdThenClick("Click on OK button",
				SignIn_pageobject.OK_BTN);
		report.reportPass("Take a screen shot after clicking the button ", true);
	}

	public void clickOnCancelButton() {
		report.reportPass("User should be on " + labels.get("enter_pin_code")
				+ " page", uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject.LABEL_TEXT(labels
						.get("enter_pin_code"))), WaitTime.getLongWaitTime(),
				WaitTime.POOLINGNANOSECONDS));
		uiActionHelper.waitForXpathThenClick("Click on Cancel button",
				SignIn_pageobject.CREATE_UR_PIN_CANCEL_BTN);
	}

	public void navigateToEnterPinCodePage() {
		report.reportPass("User should be on " + labels.get("enter_pin_code")
				+ " page", uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject.LABEL_TEXT(labels
						.get("enter_pin_code"))), WaitTime.getMediunWaitTime(),
				WaitTime.POOLINGNANOSECONDS));

	}

	public void clickOnLogInButton() {
		uiActionHelper.waitForXpathThenClick("Click on Log In button",
				SignIn_pageobject.LOGIN_BTN);
		report.reportPass("Take a screen shot after clicking the button ", true);
	}

	public void validateContactUsInfo() {

		Assert.assertTrue(uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject.LABEL_TEXT(labels
						.get("customer_service"))),
				WaitTime.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS),
				labels.get("customer_service")
						+ " label should be displayed correctly ");

		Assert.assertTrue(
				labels.get("card_service")
						.equals(uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CARD_SERVICE_LBL)),
				"Expected-> "
						+ labels.get("card_service")
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CARD_SERVICE_LBL)
						+ " text is not matching");
		Assert.assertTrue(
				labels.get("card_service_number_" + SharedDriver.product)
						.equals(uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CARD_SERVICE_NUM)),
				"Expected-> "
						+ labels.get("card_service_number_"
								+ SharedDriver.product)
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CARD_SERVICE_NUM)
						+ " text is not matching");
		Assert.assertTrue(
				labels.get("block_card")
						.equals(uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.BLOCK_CARD_LBL)),
				"Expected-> "
						+ labels.get("block_card")
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.BLOCK_CARD_LBL)
						+ " text is not matching");
		Assert.assertTrue(
				labels.get("block_card_number_" + SharedDriver.product)
						.equals(uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.BLOCK_CARD_NUM)),
				"Expected-> "
						+ labels.get("block_card_number_"
								+ SharedDriver.product)
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.BLOCK_CARD_NUM)
						+ " text is not matching");
		report.reportPass("Take a screen shot after validating labels ", true);
	}

	public void navigateToCustomerServicePage() {

		report.reportPass(
				"Expected-> "
						+ labels.get("login")
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.LOGIN_BTN)
						+ " text is not matching",
				labels.get("login")
						.equals(uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.LOGIN_BTN)));
	}

	public void validateCreatePinPopUp() {
		uiActionHelper.waitForXpath("phone image should be present ",
				SignIn_pageobject.PHONE_ICON_IMG);
		uiActionHelper.waitForXpath("PAD dots image should be present ",
				SignIn_pageobject.PAD_DOTS_IMG);
		Assert.assertEquals(
				uiActionHelper
						.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_DESC),
				labels.get("please_create_pin_code_text"),
				"Expected-> "
						+ labels.get("please_create_pin_code_text")
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_DESC)
						+ " text is not matching");
		Assert.assertEquals(
				uiActionHelper
						.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_BTN),
				labels.get("btn_create_pin"),

				"Expected-> "
						+ labels.get("btn_create_pin")
						+ " Actual-> "
						+ uiActionHelper
								.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_BTN)
						+ " text is not matching");
	}

	/*
	 * Sweden
	 */

	public void selectBankIDandEnterSecurityCode() {
		/*
		 * we could not handle it through appium tool that is why we have put
		 * the static wait so that tester can log in manually
		 */
		try {
			Thread.sleep(15000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Denmark
	 */

	public void validateSignicatMainPage_forDenmark() {
		Assert.assertEquals(labels.get("activate_app"), uiActionHelper
				.waitForIDAndGetText(SignIn_pageobject.SIGNICAT_HEADER),
				labels.get("activate_app")
						+ " text should be present on log in screen ");
		Assert.assertEquals(labels.get("activate_app"), uiActionHelper
				.waitForXPATHAndGetText(SignIn_pageobject.CREATE_YOUR_PIN_BTN),
				labels.get("activate_app")
						+ " button text should be present on log in screen ");
	}

	public void validateUserIsOnDenmarkSignicatPage() {
		uiActionHelper.waitForElementToAppear(
				By.xpath("//android.view.View[@resource-id='"
						+ SignIn_pageobject.LOADER_DK + "']"),
				" Loader should be appeared ", WaitTime.getLongWaitTime(),
				WaitTime.POOLINGNANOSECONDS);
		uiActionHelper.waitForElementToDisAppear(
				By.xpath("//android.view.View[@resource-id='"
						+ SignIn_pageobject.LOADER_DK + "']"),
				"Loader should be disappeaed ", WaitTime.getMediunWaitTime(),
				WaitTime.POOLINGNANOSECONDS);

		Assert.assertTrue(uiActionHelper.isLocatorPresent(By
				.xpath(SignIn_pageobject
						.VIEW_TEXT(SignIn_pageobject.SIGNICAT_TEXT)), WaitTime
				.getLongWaitTime(), WaitTime.POOLINGNANOSECONDS),
				"Signicate page should be diplayed to the user ");
	}

	public void enterNemID() throws InterruptedException {
		report.reportPass("Take a screen shot after entering the text ", true);
		uiActionHelper.waitForXpathClearThenType(
				"NemID textbox should be present then enter the nemID ",
				SignIn_pageobject.EDIT_TEXT(labels.get("NEM_ID")),
				configReader.getUSERNAME());

		// Thread.sleep(2000);

		report.reportPass("Expected text is => " + configReader.getUSERNAME(),
				uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
						.EDIT_TEXT(configReader.getUSERNAME())), WaitTime
						.getShortWaitTime(), WaitTime.POOLINGNANOSECONDS));
	}

	public void enterPasscode() throws InterruptedException {
		report.reportPass("Take a screen shot after clicking the button ", true);
		uiActionHelper.waitForXpathClearThenType(
				"Password textbox should be present then enter the password ",
				SignIn_pageobject.EDIT_TEXT(labels.get("PASSWORD")),
				configReader.getPASSWORD());

		// Thread.sleep(2000);

		report.reportPass("Expected text is => " + configReader.getPASSWORD(),
				uiActionHelper.isLocatorPresent(By.xpath(SignIn_pageobject
						.EDIT_TEXT(_Constants.ENCRYPTED_PERSONAL_PASSWORD
								.substring(0, 4))),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));
	}

	public void copyCodeAndSearchForOTP() {
		num = uiActionHelper.waitForXPATHAndGetAttribute(
				SignIn_pageobject.OTP_CODE(labels.get("ENTER_KEY")), "text");
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\lib\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		// driver.get("https://oces:nemid4all@appletk.danid.dk/testtools/OtpCard?CardSerial=E725955440");
		driver.get(configReader.getOTP_LINK());
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.cssSelector(SignIn_pageobject.VALIDATE_OTP_PAGE)));
		Assert.assertEquals(
				SignIn_pageobject.VALIDATE_OTP_PAGE_TEXT,
				driver.findElement(
						By.cssSelector(SignIn_pageobject.VALIDATE_OTP_PAGE))
						.getText(), "User in not on DANID Developer tool Page ");

		List<WebElement> rows = driver.findElements(By
				.xpath(SignIn_pageobject.OTP_TABLE));
		Boolean isOtpFound = false;
		loop1: for (int i = 0; i < rows.size(); i++) {
			List<WebElement> colomns = rows.get(i).findElements(
					By.xpath("//table/tbody[2]/tr/td"));
			loop2: for (int j = 0; j < colomns.size(); j++) {
				if (colomns.get(j).getText().equals(num)) {
					otp = colomns.get(j + 1).getText();
					isOtpFound = true;
					break loop2;
				} else {
					isOtpFound = false;
				}
			}
			if (isOtpFound == false)
				Assert.fail("OTP did not match");

			if (!otp.equals(null))
				break loop1;
		}
		System.out.println("OTP = > " + otp);
		driver.quit();

		// ((AndroidDriver<MobileElement>) driver)
		// .pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		// ((AndroidDriver<MobileElement>) driver)
		// .pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
	}

	public void enterSearchedOTP() {
		report.reportPass("Take a screen shot after entering the text ", true);
		uiActionHelper.waitForXpathClearThenType(
				"NemID textbox should be present then enter the nemID ",
				SignIn_pageobject.EDIT_TEXT(labels.get("ENTER_KEY")), otp);

		// Thread.sleep(2000);

		report.reportPass("Expected text is => " + otp, uiActionHelper
				.isLocatorPresent(By.xpath(SignIn_pageobject.EDIT_TEXT(otp)),
						WaitTime.getShortWaitTime(),
						WaitTime.POOLINGNANOSECONDS));
	}

	public static void main(String[] args) {
		// System.out.println();
		new SignIn_helper().copyCodeAndSearchForOTP();
	}

	public void enterThePassword() {
		uiActionHelper.waitForIdClearThenType("Enter the pin code ",
				SignIn_pageobject.ENTER_PASSWORD, configReader.getPIN_CODE());
	}

	public void pressEnterButton() {
		((AndroidDriver<MobileElement>) uiActionHelper.getWebDriver())
				.pressKeyCode(AndroidKeyCode.ENTER);
		// uiActionHelper.findElement(By.id(SignIn_pageobject.ENTER_PASSWORD))
		// .sendKeys(Keys.ENTER);
	}

}
