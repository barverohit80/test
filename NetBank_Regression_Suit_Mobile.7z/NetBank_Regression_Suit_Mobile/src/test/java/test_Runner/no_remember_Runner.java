package test_Runner;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import seleniumCore.SharedDriver;
import Utils.Start_Stop_AppiumServer;
import Utils.configReader;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(plugin = { "pretty", "html:target/cucumber-html-report_no_remember",
							"json:target/no_remember.json" },
							// tags = { "@NORWAY","@LOGIN" },
							tags = { "@NORWAY", "@REMEMBER","~@INCOMPLETE" },
							//tags = { "@NORWAY","~@INCOMPLETE", "~@SIGN_UP" },
							monochrome = true, 
							features = "classpath:features", 
							strict = true, 
							glue = "step_definitions")

public class no_remember_Runner extends AbstractTestNGCucumberTests {
	private static AndroidDriver<MobileElement> REAL_DRIVER;

	@Parameters({ "DEVICE_NAME", "UDID", "PLATFORM_V", "REGION", "LANGUAGE",
			"PRODUCT", "PORT", "SERVER_IP" })
	@BeforeClass
	public void setUp(String DeviceName, String udid, String PlatFormVersion,
			String region, String language, String product, String port,
			String ip) {
		try {
			SharedDriver.UDID = udid;
			REAL_DRIVER = SharedDriver.openApplication(new configReader(),
					region, language, DeviceName, udid, PlatFormVersion,
					product, port, ip);

			Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Thread CLOSE_THREAD = new Thread() {
		@Override
		public void run() {
			REAL_DRIVER.quit();
			Start_Stop_AppiumServer.stopServer();
		}
	};
}