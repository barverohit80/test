package seleniumCore;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import Utils._Constants;
import Utils.configReader;

public class WebDriverFactory {
	public AndroidDriver<MobileElement> CreateAndroidDriver(configReader ncr,
			String DeviceName, String udid, String PlatForm_V, String port,
			String region, String language, String ip) {
		AndroidDriver<MobileElement> driver = null;
		try {
			driver = new AndroidDriver<MobileElement>(new URL("http://" + ip
					+ ":" + port + "/wd/hub"),
					new WebDriverFactory().buildAndroidDesiredCapabilities(ncr,
							DeviceName, udid, PlatForm_V, region, language,
							port));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return driver;
	}

	protected DesiredCapabilities buildAndroidDesiredCapabilities(
			configReader ncr, String DeviceName, String udid,
			String PlatForm_V, String region, String language, String systemPort) {
		File app = new File(System.getProperty("user.dir") + ncr.getAPK());
		System.out.println(app);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
		capabilities.setCapability("deviceName", DeviceName);
		capabilities.setCapability("udid", udid);
		capabilities.setCapability("newCommandTimeout", 600);
		capabilities.setCapability("platformVersion", PlatForm_V);
		capabilities.setCapability("platformName", ncr.getPLATFORM());
		capabilities.setCapability("app", app.getAbsolutePath());
		capabilities.setCapability("automationName", "uiautomator2");
		capabilities.setCapability("unicodeKeyboard", "true");
		// default is 8200 in general and selects one port from 8200 to 8299
		capabilities.setCapability("systemPort",
				(new Integer(systemPort) + 3477) + "");
		// default is 5037
		// capabilities.setCapability("adbPort", (new Integer(systemPort) + 314)
		// + "");
		capabilities.setCapability("resetKeyboard", "true");
		capabilities.setCapability("language", _Constants.LANGUAGE[new Integer(
				language)]);
		// capabilities.setCapability("skipUnlock ", true);
		capabilities.setCapability("locale", _Constants.COUNTRY[new Integer(
				region)]);
		capabilities.setCapability("appPackage", ncr.getAPP_PACKAGE());
		System.out.println(ncr.getAPP_PACKAGE());
		capabilities.setCapability("appActivity", ncr.getAPP_ACTIVITY());
		System.out.println(ncr.getAPP_ACTIVITY());
		capabilities.setCapability("noReset", ncr.getNO_RESET());
		capabilities.setCapability("fullReset", ncr.getFULL_RESET());

		return capabilities;
	}
}
