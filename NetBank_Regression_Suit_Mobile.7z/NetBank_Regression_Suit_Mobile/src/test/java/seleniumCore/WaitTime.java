package seleniumCore;

public class WaitTime {
	public static int totalWaitTime = 0;
	private static final int SHORT = 10;
	private static final int MEDIUM = 25;
	private static final int LONG = 45;
	public static final int TIMEOUTSECONDS = 25;
	public static final int POOLINGNANOSECONDS = 300;

	public static int getShortWaitTime() {
		return SHORT;
	}

	public static int getMediunWaitTime() {
		return MEDIUM;
	}

	public static int getLongWaitTime() {
		return LONG;
	}

}
