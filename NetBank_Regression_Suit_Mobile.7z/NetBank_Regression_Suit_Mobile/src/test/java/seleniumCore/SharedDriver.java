package seleniumCore;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import java.util.HashMap;

import Utils.Start_Stop_AppiumServer;
import Utils.configReader;
import Utils.xmlReader;

/**
 * Based on shared webdriver implementation in cucumber-jvm examples A new
 * instance of SharedDriver is created for each Scenario and passed to Stepdef
 * classes via Dependency Injection
 */
public class SharedDriver {

	private static AndroidDriver<MobileElement> REAL_DRIVER;
	public static configReader configreader;
	public static HashMap<String, String> labels;
	public static int regionCode = 0, language = 0;
	public static String UDID, product;

	public static AndroidDriver<MobileElement> openApplication(
			configReader ncr, String region, String language,
			String DeviceName, String udid, String PlatForm_V, String product,
			String port, String ip) {
		try {
			// SharedDriver.config = ncr;
			// SharedDriver.deviceName = DeviceName;
			// SharedDriver.platformV = PlatForm_V;
			// SharedDriver.port = port;
			SharedDriver.language = new Integer(language);
			SharedDriver.regionCode = new Integer(region);
			SharedDriver.configreader = new configReader(
					SharedDriver.regionCode, product);
			SharedDriver.product = product;
			SharedDriver.labels = xmlReader
					.readXMLTagValueByNameAttribute(new Integer(language));
			Start_Stop_AppiumServer.startServer(ip, new Integer(port), udid);
			SharedDriver.REAL_DRIVER = new WebDriverFactory()
					.CreateAndroidDriver(ncr, DeviceName, udid, PlatForm_V,
							port, region, language, ip);
			// Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return SharedDriver.REAL_DRIVER;
	}

	public static Thread CLOSE_THREAD = new Thread() {
		@Override
		public void run() {
			SharedDriver.REAL_DRIVER.quit();
			Start_Stop_AppiumServer.stopServer();
		}
	};

	public AndroidDriver<MobileElement> getDriver() {
		return REAL_DRIVER;
	}

	// public SharedDriver() {
	// super(REAL_DRIVER);
	// }

	// @Before
	/**
	 * Delete all cookies at the start of each scenario to avoid shared state
	 * between tests
	 */
	public void deleteAllCookies() {
		REAL_DRIVER.manage().deleteAllCookies();
	}

	// @After
	/**
	 * Embed a screenshot in test report if test is marked as failed
	 */
	/*
	 * public void embedScreenshot(Scenario scenario) {
	 * scenario.write("Current Page URL is " + REAL_DRIVER.getCurrentUrl()); try
	 * { byte[] screenshot = ((TakesScreenshot) REAL_DRIVER)
	 * .getScreenshotAs(OutputType.BYTES); scenario.embed(screenshot,
	 * "image/png"); } catch (WebDriverException
	 * somePlatformsDontSupportScreenshots) { System.err
	 * .println(somePlatformsDontSupportScreenshots.getMessage()); } }
	 */

}
