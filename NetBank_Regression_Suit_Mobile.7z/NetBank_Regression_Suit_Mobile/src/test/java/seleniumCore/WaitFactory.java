package seleniumCore;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitFactory {

	public WaitFactory() {
	}

	public FluentWait<WebDriver> newCustomeWait(WebDriver webDriver,
			final int timeOutSeconds) {

		return new WebDriverWait(webDriver, timeOutSeconds);

	}

	public FluentWait<WebDriver> newFluentWait(WebDriver webDriver,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {
		return new FluentWait<WebDriver>(webDriver)
				.withTimeout(timeOutSeconds, TimeUnit.SECONDS)
				.pollingEvery(poolingNanoSecounds, TimeUnit.NANOSECONDS)
				.withMessage(message).ignoring(NoSuchElementException.class);

	}

	public FluentWait<WebDriver> newFluentWaitTemp(WebDriver webDriver,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {
		return new FluentWait<WebDriver>(webDriver)
				.withTimeout(timeOutSeconds, TimeUnit.SECONDS)
				.pollingEvery(poolingNanoSecounds, TimeUnit.NANOSECONDS)
				.withMessage(message);

	}
}
