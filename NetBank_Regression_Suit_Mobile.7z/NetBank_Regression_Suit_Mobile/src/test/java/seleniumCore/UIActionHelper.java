package seleniumCore;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.Scenario;

public class UIActionHelper {

	// public static String Region;
	private static AndroidDriver<MobileElement> webDriver;
	private final TreeSet<String> browserHandles = new TreeSet<String>();
	// private WebDriverFactory launchMobileApp = null;
	private WaitFactory waitFactory;
	static final int DEFAULT_DIV_WAIT_LOADING_SECONDS = 20;
	private int divWaitLoadingSeconds;
	static final int DEFAULT_WAIT_SECONDS = 20;
	private int waitSeconds = WaitTime.TIMEOUTSECONDS;
	static final int DEFAULT_POOLING_NANOSECONDS = 500;
	private int poolingNanoSeconds = WaitTime.POOLINGNANOSECONDS;

	public UIActionHelper() {

	}

	public UIActionHelper(AndroidDriver<MobileElement> driver)
			throws FileNotFoundException, IOException {
		webDriver = driver;
		this.waitFactory = new WaitFactory();
	}

	public void initTiming() {
		waitSeconds = DEFAULT_WAIT_SECONDS;
		if ("true".equals("true")) {
			waitSeconds = Integer.parseInt("" + 20);
		}
		divWaitLoadingSeconds = DEFAULT_DIV_WAIT_LOADING_SECONDS;
		String divWaitLoadingSecondsStr = "20";
		if (divWaitLoadingSecondsStr != null
				&& divWaitLoadingSecondsStr.length() != 0) {
			divWaitLoadingSeconds = Integer.parseInt(divWaitLoadingSecondsStr);
		}
		poolingNanoSeconds = DEFAULT_POOLING_NANOSECONDS;
	}

	public WaitFactory getWaitFactory() {
		return this.waitFactory;
	}

	public String getWebDriverCurrentUrl() {
		return webDriver.getCurrentUrl();
	}

	public void reMaxmize() {
		getWebDriver().manage().window()
				.setSize(new org.openqa.selenium.Dimension(0, 0));
		getWebDriver().manage().window().maximize();
	}

	@Deprecated
	public Set<String> getBrowserHandles() {
		return browserHandles;
	}

	public Boolean checkIfElementIsVisible(String componentId,
			final int timeOutSeconds, final int poolingNanoSecounds) {

		try {
			waitForElementToAppear(By.id(componentId),
					"waiting for the element to appear", timeOutSeconds,
					poolingNanoSecounds);
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}

	public void switchToNewlyOpenedWindow() {
		String parentWindow = webDriver.getWindowHandle();
		browserHandles.toString();
		if (browserHandles.contains(parentWindow) == false) {
			browserHandles.add(parentWindow);
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		webDriver.getWindowHandles();
		Set<String> newHandleIndentifierSet = webDriver.getWindowHandles();
		System.out.println(newHandleIndentifierSet.size());
		newHandleIndentifierSet.removeAll(browserHandles);
		String popUpHandle = newHandleIndentifierSet.iterator().next();
		webDriver.switchTo().window(popUpHandle);

	}

	public String waitForXPATHAndGetText(String Xpath) {
		waitForElement("Xpath String", Xpath,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(Xpath)));
		return findElement(By.xpath(Xpath)).getText();
	}

	public void waitForXpathThenSelectValue(String message, String xpath,
			String selectString) throws TimeoutException {
		waitForXpath(message, xpath);
		Select select = createnewSelect(findElement(By.xpath(xpath)));
		select.selectByValue(selectString);
	}

	public void waitForXpathClearThenType(String message, String xpath,
			String data) throws TimeoutException {

		waitForXpath(message, xpath);
		WebElement ele = findElement(By.xpath(xpath));
		// ele.click();
		ele.clear();
		ele.sendKeys(data);

	}

	public void waitForCSSClearThenType(String message, String CSS, String data)
			throws TimeoutException {

		waitForCSS(message, CSS);
		WebElement ele = findElement(By.cssSelector(CSS));
		// ele.click();
		ele.clear();
		ele.sendKeys(data);
	}

	public void compareHashMap(HashMap<String, String> expected,
			HashMap<String, String> actual) {
		for (final String key : expected.keySet()) {
			if (actual.containsKey(key)) {
				Assert.assertTrue(expected.get(key).equals(actual.get(key)),
						"Expected value" + expected.get(key)
								+ "is not matching with" + actual.get(key)
								+ "Actual value");
				System.out.println("HashMap1 " + expected.get(key) + " "
						+ "HashMap2 " + actual.get(key));
			} else {
				Assert.fail(actual.get(key) + " is not present in "
						+ expected.get(key));
			}
		}
	}

	public String waitForIDAndGetText(String ID) {
		waitForElement("ID String", ID,
				ExpectedConditions.visibilityOfElementLocated(MobileBy.id(ID)));
		return findElement(MobileBy.id(ID)).getText();
	}

	public String waitForIDAndGetAttribute(String ID, String AttributeName) {
		waitForElement("ID String", ID,
				ExpectedConditions.visibilityOfElementLocated(By.id(ID)));
		return findElement(MobileBy.id(ID)).getAttribute(AttributeName);
	}

	public String waitForXPATHAndGetAttribute(String Xpath, String AttributeName) {
		waitForElement("Xpath String", Xpath,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(Xpath)));
		return findElement(By.xpath(Xpath)).getAttribute(AttributeName);
	}

	public String waitForCSSAndGetAgttribute(String CSS, String AttributeName) {
		waitForElement("CSS String", CSS,
				ExpectedConditions.visibilityOfElementLocated(By
						.cssSelector(CSS)));
		return findElement(By.cssSelector(CSS)).getAttribute(AttributeName);
	}

	public void get(String url) {
		webDriver.get(url);
	}

	public List<MobileElement> findElements(By by) {
		waitForElementToAppear(by,
				"wait for " + by + " element to be located ",
				WaitTime.getMediunWaitTime(), WaitTime.POOLINGNANOSECONDS);
		return webDriver.findElements(by);

	}

	public String getPageTitle() {
		return webDriver.getTitle();
	}

	public String waitForCSSAndGetText(String cssString) {
		waitForElement("CSS String", cssString,
				ExpectedConditions.visibilityOfElementLocated(By
						.cssSelector(cssString)));
		return findElement(By.cssSelector(cssString)).getText();
	}

	public <T> void waitForElement(String message, String elementLocator,
			ExpectedCondition<T> expectedCondition) {
		String msg = null;
		if (elementLocator == null || elementLocator.length() == 0) {
			msg = "[no ID Supplied]";
		} else {
			msg = elementLocator;
		}

		try {
			waitFactory
					.newFluentWait(
							webDriver,
							"Timed out waiting for element: " + msg
									+ "to appear", waitSeconds,
							poolingNanoSeconds)
					.ignoring(NoSuchElementException.class)
					.until(expectedCondition);
		} catch (StaleElementReferenceException e) {
			waitFactory
					.newFluentWait(
							webDriver,
							"Timed out waiting for element: " + msg
									+ "to appear", waitSeconds,
							poolingNanoSeconds)
					.ignoring(NoSuchElementException.class)
					.until(expectedCondition);
		}

	}

	public void waitForId(String message, String id) throws TimeoutException {
		waitForElement(message, id,
				ExpectedConditions.visibilityOfElementLocated(By.id(id)));

	}

	public void waitForElementToBeClickableById(String message, String id)
			throws TimeoutException {
		waitForElement(message, id,
				ExpectedConditions.elementToBeClickable(By.id(id)));
	}

	public void waitForElementToBeClickableByName(String message, String name)
			throws TimeoutException {
		waitForElement(message, name,
				ExpectedConditions.elementToBeClickable(By.name(name)));
	}

	public void waitForElementToAppear(final By selector, final String message,
			final int timeOutSeconds, final int poolingNanoSecounds) {

		try {

			waitFactory
					.newFluentWait(webDriver, message, timeOutSeconds,
							poolingNanoSecounds)
					.ignoring(NoSuchElementException.class)
					.until(ExpectedConditions
							.visibilityOfElementLocated(selector));
		} catch (Exception e) {
			Assert.fail("unable to locate the element " + selector + "  "
					+ e.getMessage());
		}
	}

	public void scrollDown(WebElement selector) {
		((JavascriptExecutor) webDriver).executeScript(
				"arguments[0].scrollIntoView(true);", selector);

	}

	public void waitForElementToAppearTemp(final By selector,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {
		waitFactory.newFluentWaitTemp(webDriver, message, timeOutSeconds,
				poolingNanoSecounds).until(
				ExpectedConditions.visibilityOfElementLocated(selector));
	}

	public void waitForIdClearThenType(String message, String id, String data)
			throws TimeoutException {
		waitForId(message, id);
		WebElement ele = findElement(By.id(id));
		// ele.click();
		ele.clear();
		ele.sendKeys(data);
	}

	public void waitForIdClearThenType(String message, String id, Keys data)
			throws TimeoutException {

		waitForId(message, id);
		WebElement ele = findElement(By.id(id));
		// ele.click();
		ele.clear();
		ele.sendKeys(data);

	}

	public void waitForFrameAndSwitchToIt(String frameLocator) {
		waitForElement("Frame name or id", "",
				ExpectedConditions
						.frameToBeAvailableAndSwitchToIt(frameLocator));
	}

	public void waitForInvisibilityOfLinkText(String text) {
		waitForElement("Link text", "",
				ExpectedConditions.invisibilityOfElementLocated(By
						.linkText(text)));
	}

	public void alertHandlerAccept() {
		Alert alert = getWebDriver().switchTo().alert();
		alert.accept();
	}

	public void alertHandlerSendKeys(String KeyToSend) {
		Alert alert = getWebDriver().switchTo().alert();
		alert.sendKeys(KeyToSend);
	}

	public void waitForInvisibilityOfTable(String message, String xPath) {
		waitForElement(
				message,
				xPath,
				ExpectedConditions.invisibilityOfElementLocated(By.xpath(xPath)));
	}

	public void waitForVisibilityOfLinkText(String text) {
		waitForElement("Link text", "",
				ExpectedConditions.invisibilityOfElementLocated(By
						.linkText(text)));

	}

	public void waitForEitherIdThenClick(String message, String id1,
			String id2, String id3) throws TimeoutException {

		try {
			waitForId(message, id1);
			findElement(By.id(id1)).click();
		} catch (Throwable e) {

			try {
				waitForId(message, id2);
				findElement(By.id(id2)).click();

			} catch (Throwable e2) {
				waitForId(message, id3);
				findElement(By.id(id3)).click();
			}
		}

	}

	public void waitForIdThenSendKeys(String message, String id, Keys keys)
			throws TimeoutException {

		waitForId(message, id);
		findElement(By.id(id)).sendKeys(keys);
	}

	public void waitForIdThenSelect(String message, String id,
			String selectString) throws TimeoutException {
		waitForId(message, id);
		Select select = createnewSelect(findElement(By.id(id)));
		select.selectByVisibleText(selectString);
	}

	// public void waitForIdThenSelectUsingRegex(String message, String id,
	// String selectRegex) throws TimeoutException {
	// waitForId(message, id);
	// Select select = createnewSelect(findElement(By.id(id)));
	//
	// List<MobileElement> elements = select.getOptions();
	// for (WebElement element : elements) {
	// String text = element.getText();
	// if (text.matches(selectRegex)) {
	// select.selectByVisibleText(text);
	// return;
	// }
	//
	// }
	// }

	// public void waitForIdThenSelectUsingContainsRegex(String message,
	// String id, String selectRegex) throws TimeoutException {
	// waitForId(message, id);
	// Select select = createnewSelect(findElement(By.id(id)));
	//
	// List<MobileElement> elements = select.getOptions();
	// for (WebElement element : elements) {
	// String text = element.getText();
	// if (text.matches(selectRegex)) {
	// select.selectByVisibleText(text);
	// return;
	// }
	//
	// }
	//
	// }

	@Deprecated
	public boolean waitForIdThenVerifySelected(String message, String id)
			throws TimeoutException {

		return waitForIdThenVerifyChecked(message, id);
	}

	public boolean waitForIdThenVerifyChecked(String message, String id)
			throws TimeoutException {

		waitForId(message, id);
		return findElement(By.id(id)).isSelected();
	}

	public boolean waitForIdThenVerifyContainsText(String message,
			String string, String id) throws TimeoutException {
		waitFactory.newFluentWait(webDriver, "Timed out waiting for element:"
				+ id + "to appear", 7, poolingNanoSeconds);
		ExpectedConditions.textToBePresentInElementLocated(By.id(id), string);
		return findElement(By.id(id)).getText().contains(string);

	}

	public boolean waitForIdThenVerifyContainsHtml(String message,
			String string, String id) throws TimeoutException {
		waitFactory.newFluentWait(webDriver, "Timed out waiting for element:"
				+ id + "to appear", 7, poolingNanoSeconds);
		return findElement(By.id(id)).getAttribute("innerHtml")
				.contains(string);

	}

	public boolean waitForiIdThenVerifyInputMatchesRegex(String message,
			String id, String regex) throws TimeoutException {

		waitForId(message, id);
		return findElement(By.id(id)).getAttribute("value").matches(regex);
	}

	public boolean waitForIdThenVerifySelected(String message, String expected,
			String id) throws TimeoutException {
		waitForId(message, id);
		Select select = createnewSelect(findElement(By.id(id)));
		return expected.equals(select.getFirstSelectedOption().getText());
	}

	public boolean waitForIdThenVerifyNoneSelected(String message, String id)
			throws TimeoutException {
		waitForId(message, id);
		Select select = createnewSelect(findElement(By.id(id)));
		return select.getAllSelectedOptions().isEmpty();
	}

	public Select createnewSelect(WebElement webElement) {
		return new Select(webElement);
	}

	public void waitForIdsThenSelectedFromJsSearchableList(
			String listComponentId, String valueListComponentId,
			String valueToSelect, String message) throws TimeoutException {
		waitForIdThenClick(message, listComponentId);
		waitForXpathThenClick(message, "//div[@id=" + valueListComponentId
				+ "']/div[@title='" + valueToSelect + "']");

	}

	public void waitForName(String message, String name) {
		waitForElement(message, name,
				ExpectedConditions.visibilityOfElementLocated(By.name(name)));
	}

	public void waitForNameThenClick(String message, String name) {
		waitForName(message, name);
		findElement(By.name(name)).click();
	}

	public void waitForNameThenSelect(String message, String name,
			String selectString) throws TimeoutException {
		waitForId(message, name);
		Select select = createnewSelect(findElement(By.name(name)));
		select.selectByVisibleText(selectString);
	}

	public void waitForNameThenType(String message, String name, String input)
			throws TimeoutException {
		waitForId(message, name);
		findElement(By.name(name)).sendKeys(input);
	}

	public void waitForCSS(String message, String CSS) {
		waitForElement(message, CSS,
				ExpectedConditions.visibilityOfElementLocated(By
						.cssSelector(CSS)));

	}

	public void waitForXpath(String message, String xpath) {
		waitForElement(message, xpath,
				ExpectedConditions.presenceOfElementLocated(MobileBy
						.xpath(xpath)));
	}

	public WebElement waitForXpathAndGetElement(String message, String xPath) {
		waitForElement(message, xPath,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(xPath)));
		return findElement(By.name(xPath));
	}

	public void waitForXpathThenType(String message, String xPath,
			String selectString) throws TimeoutException {
		waitForXpath(message, xPath);
		findElement(By.xpath(xPath)).sendKeys(selectString);
	}

	public void waitForXpathThenClick(String message, String xPath) {
		// waitForXpath(message, xPath);
		waitForElement(message, xPath,
				ExpectedConditions.elementToBeClickable(By.xpath(xPath)));
		findElement(By.xpath(xPath)).click();
	}

	public void waitForCSSThenClick(String message, String CSS) {
		waitForCSS(message, CSS);
		findElement(By.cssSelector(CSS)).click();
	}

	public void waitForXpathThenDoAction(String message, String xPath) {
		waitForXpath(message, xPath);
		Actions act = new Actions(webDriver);
		act.moveToElement(findElement(By.xpath(xPath))).click().perform();
	}

	public void waitForXpathThenSelect(String message, String xPath,
			String selectString) throws TimeoutException {
		waitForXpath(message, xPath);
		Select select = createnewSelect(findElement(By.xpath(xPath)));
		select.selectByVisibleText(selectString);
	}

	public void waitForClass(String message, String className) {
		waitForElement(message, className,
				ExpectedConditions.presenceOfElementLocated(By
						.className(className)));
	}

	public void waitForClassClearThenType(String message, String className,
			String data) throws TimeoutException {
		try {

			waitForClass(message, className);
			WebElement ele = findElement(By.className(className));
			// ele.click();
			ele.clear();
			ele.sendKeys(data);
		} catch (StaleElementReferenceException e) {
			waitForClass(message, className);
			WebElement ele = findElement(By.className(className));
			// ele.click();
			ele.clear();
			ele.sendKeys(data);
		}
	}

	public String waitForClassAndGetText(String className) {
		waitForElement("Class String", className,
				ExpectedConditions.visibilityOfElementLocated(By
						.className(className)));
		return findElement(By.className(className)).getText();
	}

	public void waitForLinkText(String message, String linkText) {
		waitForElement(message, linkText,
				ExpectedConditions.visibilityOfElementLocated(By
						.linkText(linkText)));
	}

	public void waitForLinkTextThenClick(String message, String linkText) {
		waitForLinkText(message, linkText);
		findElement(By.linkText(linkText)).click();
	}

	public void waitForElementToDisAppear(final By selector,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {

		waitFactory
				.newFluentWait(webDriver, message, timeOutSeconds,
						poolingNanoSecounds)
				.ignoring(NoSuchElementException.class)
				.until(ExpectedConditions
						.invisibilityOfElementLocated(selector));
	}

	public void waitForElementToBePresent(final By selector,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {

		waitFactory
				.newFluentWait(webDriver, message, timeOutSeconds,
						poolingNanoSecounds)
				.ignoring(NoSuchElementException.class)
				.until(ExpectedConditions.presenceOfElementLocated(selector));
	}

	public void waitForElementToNotBePresent(final By selector,
			final String message, final int timeOutSeconds,
			final int poolingNanoSecounds) {
		ExpectedCondition<Boolean> condition = new ExpectedCondition<Boolean>() {

			public Boolean apply(final WebDriver webDriver) {
				try {
					findElement(selector);
					return false;
				} catch (NoSuchElementException e) {
					return true;
				}
			}
		};
		waitFactory
				.newFluentWait(webDriver, message, timeOutSeconds,
						poolingNanoSecounds)
				.ignoring(NoSuchElementException.class).until(condition);

	}

	public void waitForLoadingDivToComplete() {
		try {
			waitForElementToAppear(By.id("loadingInnerDiv"),
					"Time out waiting on InnerDiv", divWaitLoadingSeconds,
					poolingNanoSeconds);
			waitForElementToBePresent(By.id("loadingInnerDiv"),
					"Time out waiting on InnerDiv", divWaitLoadingSeconds,
					poolingNanoSeconds);
		} catch (TimeoutException e) {

		}
	}

	public void dependableClick(By by) {
		final int MAXIMUM_WAIT_TIME = 10;
		final int MAXIMUM_STALE_ELEMENT_RETRIES = 5;
		int retries = 0;
		while (true) {
			try {
				waitFactory.newCustomeWait(webDriver, MAXIMUM_WAIT_TIME)
						.until(ExpectedConditions.elementToBeClickable(by))
						.click();
				return;
			} catch (StaleElementReferenceException e) {
				if (retries < MAXIMUM_STALE_ELEMENT_RETRIES) {
					retries++;
					continue;
				} else {
					throw e;
				}
			}
		}

	}

	public void clickOnButtonThatInvokesAlert(String componentId)
			throws Throwable {
		try {
			waitForIdThenClick("Clicking on Button" + componentId, componentId);
			waitForLoadingDivToComplete();
		} catch (UnhandledAlertException uae) {
			try {
				Alert alert = getWebDriver().switchTo().alert();
				alert.accept();
			} catch (NoAlertPresentException nape) {

			}
		}
	}

	public WebElement findElement(By by) {
		return webDriver.findElement(by);

	}

	public WebElement findElementById(String id) {
		return webDriver.findElementById(id);

	}

	public void waitForAccessibilityId(String Message, String AccessibilityId) {
		waitForElement(Message, AccessibilityId,
				ExpectedConditions.elementToBeClickable(MobileBy
						.AccessibilityId(AccessibilityId)));
	}

	public void waitForAccessibilityIdThenClick(String Message,
			String AccessibilityId) {
		waitForElement(Message, AccessibilityId,
				ExpectedConditions.elementToBeClickable(MobileBy
						.AccessibilityId(AccessibilityId)));
		findElement(MobileBy.AccessibilityId(AccessibilityId)).click();
	}

	public String waitForAccessibilityIdAndGetAttribute(String AccessibilityId,
			String AttributeName) {
		waitForElement("AccessibilityId String", AccessibilityId,
				ExpectedConditions.visibilityOfElementLocated(MobileBy
						.AccessibilityId(AccessibilityId)));
		return findElement(MobileBy.AccessibilityId(AccessibilityId))
				.getAttribute(AttributeName);
	}

	public void waitForIdThenClick(String message, String id)
			throws TimeoutException {
		waitForElement(message, id,
				ExpectedConditions.elementToBeClickable(By.id(id)));

		findElementById(id).click();
		// findElement(By.id(id)).click();

	}

	public void waitForClassThenClick(String message, String className)
			throws TimeoutException {
		waitForElement(
				message,
				className,
				ExpectedConditions.elementToBeClickable(By.className(className)));
		findElement(By.className(className)).click();

	}

	public AndroidDriver<MobileElement> getWebDriver() {
		return webDriver;
	}

	public void selectRadioButtonValue(String message, String locator,
			String value) {
		waitForElement(
				message,
				locator,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		List<MobileElement> radio = findElements(By.xpath(locator));

		int iSize = radio.size();

		for (int i = 0; i < iSize; i++) {

			String sValue = radio.get(i).getAttribute("value").trim();

			if (sValue.equalsIgnoreCase(value)) {

				radio.get(i).click();
				break;
			}
		}
	}

	public Boolean isSelectedRadioButtonValue(String message, String locator,
			String value) {
		waitForElement(
				message,
				locator,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		List<MobileElement> radio = findElements(By.xpath(locator));

		int iSize = radio.size();
		Boolean boo = false;

		for (int i = 0; i < iSize; i++) {

			String sValue = radio.get(i).getAttribute("value").trim();

			if (sValue.equalsIgnoreCase(value)) {

				boo = radio.get(i).isSelected();
				break;
			}
		}
		return boo;
	}

	public void selectRadioButtonByIndex(String message, String locator,
			int index) {
		waitForElement(message, locator,
				ExpectedConditions.visibilityOfElementLocated(By
						.cssSelector(locator)));
		List<MobileElement> radio = findElements(By.cssSelector(locator));

		int iSize = radio.size();

		for (int i = 0; i < iSize; i++) {

			if (index == i) {

				radio.get(i).click();
				break;
			}
		}
	}

	public void validateRadioButtonValues(String message, String locator,
			String[] arr) {
		waitForElement(
				message,
				locator,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		List<MobileElement> radio = findElements(By.xpath(locator));

		int iSize = radio.size();

		if (iSize == arr.length) {
			for (int i = 0; i < iSize; i++) {

				String sValue = radio.get(i).getAttribute("value").trim();

				if (sValue.equalsIgnoreCase(arr[i])) {

					radio.get(i).click();
					break;
				}
			}
		} else {
			Assert.fail("Radio Button count is not matching ");
		}
	}

	public void selectCheckBox(String message, String locator, int index) {
		waitForElement(
				message,
				locator,
				ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
		List<MobileElement> checkBox = webDriver
				.findElements(By.xpath(locator));
		checkBox.get(index).click();

	}

	public void closeAllButOneBrowser() {
		while (webDriver.getWindowHandles().size() > 1) {
			webDriver.close();
		}
		webDriver.switchTo().window(
				webDriver.getWindowHandles().iterator().next());
	}

	public void embedMessage(Scenario scenario, String message) {
		scenario.write(message);
	}

	public void quitWebDriver() {
		webDriver.quit();
	}

	public boolean isElementVisible(String cssLocator) {
		return findElement(By.cssSelector(cssLocator)).isDisplayed();
	}

	public boolean isElementPresent(By locatorKey) {
		try {
			findElement(locatorKey);
			// waitForElementToAppear(locatorKey, "Wait for element", 20, 250);
			return true;
		} catch (org.openqa.selenium.NoSuchElementException e) {
			return false;
		}
	}

	public boolean waitForElement(By locatorKey, int time)
			throws InterruptedException {
		boolean boo = false;
		for (int i = 0; i < time; i++) {
			if (isElementPresent(locatorKey)) {
				boo = true;
				break;
			} else {
				Thread.sleep(1000);
			}
		}
		return boo;
	}

	public boolean isLocatorPresent(By locatorKey, int timeInSeconds,
			int pollingMiliSeconds) {
		try {
			waitForElementToBePresent(locatorKey, locatorKey
					+ " Element is not visible ", timeInSeconds,
					pollingMiliSeconds);

			return true;

		} catch (Exception e) {
			return false;
		}
	}

	public boolean isChildElementPresent(WebElement element, By childElement) {
		try {
			element.findElement(childElement);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void selectByVisibleText(String message, String xPath,
			String visibleText) {
		waitForXpath(message, xPath);
		WebElement ele = findElement(By.xpath(xPath));
		Select sl = new Select(ele);
		sl.selectByVisibleText(visibleText);
	}

	public void selectByIndex(String message, String xPath, int index) {
		waitForXpath(message, xPath);
		WebElement ele = findElement(By.xpath(xPath));
		Select sl = new Select(ele);
		sl.selectByIndex(index);
	}

	public void selectByValue(String message, String xPath, String value) {
		waitForXpath(message, xPath);
		WebElement ele = findElement(By.xpath(xPath));
		Select sl = new Select(ele);
		sl.selectByValue(value);
	}

	public void selectdate(String year, String yearXpath, String month,
			String monthXpath, String dateXpath) {
		selectByVisibleText("Select year", yearXpath, year);
		selectByVisibleText("Select Month", monthXpath, month);
		waitForXpathThenClick("Select date", dateXpath);
	}

	public WebElement expandRootElement(WebElement element) {
		WebElement ele = (WebElement) ((JavascriptExecutor) webDriver)
				.executeScript("return arguments[0].shadowRoot", element);
		return ele;
	}

	public String getHiddenText(WebElement element) {

		JavascriptExecutor js = (JavascriptExecutor) ((RemoteWebElement) element)
				.getWrappedDriver();

		return (String) js.executeScript("return arguments[0].text", element);

	}

/*	public boolean isImagePresent(Screen screen, String image, int i, int time) {
		boolean status = false;
		try {
			screen.find(image);
			status = true;
		} catch (FindFailed e) {
			if (i == time - 1) {
				e.printStackTrace();
				System.out.println(i);
				Assert.fail("Unable to find " + image);
			}
		}
		return status;
	}

	public void waitForImage(Screen screen, String image, int time)
			throws InterruptedException {
		for (int i = 0; i < time; i++) {
			if (isImagePresent(screen, image, i, time)) {
				break;
			} else {
				Thread.sleep(1000);
			}
		}
	}
*/
	public void waitForChildElement(WebElement element, By childElement,
			int time) throws InterruptedException {
		for (int i = 0; i < time; i++) {
			if (isChildElementPresent(element, childElement)) {
				break;
			} else {
				Thread.sleep(1000);
			}
		}
	}

	public void waitForIdAndValidateText(String id, String expectedText) {
		report.reportPass("Expected-> " + expectedText + " Actual-> "
				+ waitForIDAndGetText(id) + " text is not matching",
				expectedText.equals(waitForIDAndGetText(id)));
	}

	public void waitForXpathAndValidateText(String xpath, String expectedText) {
		report.reportPass("Expected-> " + expectedText + " Actual-> "
				+ waitForXPATHAndGetText(xpath) + " text is not matching",
				expectedText.equals(waitForXPATHAndGetText(xpath)));
	}

	public WebElement findElementByUIAutomator(String UiSelector) {
		return (MobileElement) webDriver
				.findElementByAndroidUIAutomator(UiSelector);
	}

	public void waitForUiSelector(String Message, String UiSelector) {
		WebElement mobileElement = (MobileElement) webDriver
				.findElementByAndroidUIAutomator(UiSelector);
		waitFactory.newFluentWaitTemp(webDriver, Message,
				WaitTime.getMediunWaitTime(), WaitTime.POOLINGNANOSECONDS)
				.until(ExpectedConditions.visibilityOf(mobileElement));
	}

	public String waitForUiSelctorThenGetText(String Message, String UiSelector) {
		waitForUiSelector(Message, UiSelector);
		return findElementByUIAutomator(UiSelector).getText();
	}

	public void scrolltoViewRecords(WebElement scrollTill, WebElement scrollFrom) {
		TouchAction act = new TouchAction(webDriver);
		act.press(scrollFrom).waitAction(java.time.Duration.ofMillis(5400))
				.moveTo(scrollTill).release().perform();
	}

	public void scrolltoViewRecords(int x, int y, WebElement scrollFrom) {
		TouchAction act = new TouchAction(webDriver);
		act.press(scrollFrom).waitAction(java.time.Duration.ofMillis(5000))
				.moveTo(x, y).release().perform();
	}

	public void scrolltoView(int topX, int topY, int bottomX, int bottomY,
			int waitime) {
		TouchAction act = new TouchAction(webDriver);
		act.press(bottomX, bottomY)
				.waitAction(java.time.Duration.ofMillis(waitime))
				.moveTo(topX, topY).release().perform();
	}

	public void scrollToElement_Using_rource_id(By by, String reourceId) {
		MobileElement ele = webDriver.findElement(by);
		((AndroidElement) ele)
				.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
						+ "new UiSelector().resourceIdMatches(\".*:"
						+ reourceId + "\"))");

	}

	public void scrollToElement_Using_className(String childClass) {
		findElementByUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("
				+ "new UiSelector().className(\"" + childClass + "\"))");
	}
}
