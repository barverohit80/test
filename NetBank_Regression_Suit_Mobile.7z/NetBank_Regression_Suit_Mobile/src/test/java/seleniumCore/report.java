package seleniumCore;

import org.testng.Assert;

import step_definitions.Hooks;

public class report {
	/*
	 * private static Scenario scenario; private static WebDriver driver;
	 * private static String folder;
	 * 
	 * static int i = 0;
	 * 
	 * public report(Scenario scenario, WebDriver driver, String folder) {
	 * report.scenario = scenario; report.driver = driver; report.folder =
	 * folder; }
	 */

	/*
	 * public static void reportStatus(String status, String Message, Boolean
	 * condition) { AttachScreenshot(); if (status.equalsIgnoreCase("Pass")) {
	 * System.out.println("Test Pass"); reportPass(Message, condition); } else
	 * if (status.equalsIgnoreCase("Fail")) { System.out.println("Test Fail");
	 * reportFail(Message); } else if (status.equalsIgnoreCase("Pending")) {
	 * System.out.println("Test Pending"); reportPending(Message, condition); }
	 * }
	 */

	public static void reportPass(String Message, Boolean boo) {
		Hooks.AttachScreenshot();
		Assert.assertTrue(boo, Message);
	}

	public static void reportFail(String Message) {
		Hooks.AttachScreenshot();
		Assert.fail(Message);
	}

	public static void reportPending(String Message, Boolean boo) {
		System.out.println("Pending");
	}

	/*
	 * public static void AttachScreenshot() { try { if
	 * (SharedDriver.configreader.getScreenShot().equals("true")) { File src =
	 * ((TakesScreenshot) driver) .getScreenshotAs(OutputType.FILE); String
	 * screenShot = util.dateAndTime("yyyy_MM_dd_HH_mm_ss_S") + ".jpeg";
	 * FileUtils.copyFile(src, new File(
	 * "target/cucumber-html-report_screenShots/" +
	 * _Constants.COUNTRY[SharedDriver.regionCode] + "/" + folder + "/" +
	 * screenShot));
	 * 
	 * String newFileNamePath = "<a id=\"lol" + i +
	 * "\" class=\"passed\" onclick=\"var im=document.getElementById('topo" + i
	 * + "'); " +
	 * "var imgStack=document.querySelectorAll('[id*=\\\'topo\\\']'); for(var i=0; i<imgStack.length; i++) { if(imgStack[i].id!=='topo'+this.id.match(/[0-9]+/)) imgStack[i].style.display='none'  }; im.style.display = (im.style.display == 'none' ? 'block' : 'none');\">"
	 * + "<b>screenshot</b>" + "</a>" + "  <img id=\"topo" + i +
	 * "\" style=\"display: none;\" height=\"736\" width=\"435\"" +
	 * "src=\"file:///" + System.getProperty("user.dir") +
	 * "/target/cucumber-html-report_screenShots/" +
	 * _Constants.COUNTRY[SharedDriver.regionCode] + "/" + folder + "/" +
	 * screenShot + "\"/></br>";
	 * 
	 * // String newFileNamePath = "<a id=\"lol" // + i // + //
	 * "\" class=\"passed\" href onclick=\"var im=document.getElementById('topo"
	 * +i // + "'); " // + //
	 * "im.style.display = (im.style.display == 'none' ? 'block' : 'none');return false\">"
	 * // + "<b>screenshot</b>" + "</a>" + "  <img id=\"topo"+i // +
	 * "\" style=\"display: none;\" " + "src=\"file:///" // +
	 * System.getProperty("user.dir") // + "/target/cucumber-html-report/" // +
	 * main_Stepdfination.region + "/" + folder + "/" // + screenShot +
	 * "\"/></br>";
	 * 
	 * scenario.write(newFileNamePath); i++; } } catch (WebDriverException
	 * somePlatformsDontSupportScreenshots) { System.err
	 * .println(somePlatformsDontSupportScreenshots.getMessage()); } catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace();
	 * }
	 * 
	 * // } }
	 */

}
