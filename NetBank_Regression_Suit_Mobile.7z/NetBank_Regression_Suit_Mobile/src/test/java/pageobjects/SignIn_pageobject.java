package pageobjects;

public class SignIn_pageobject {

	public static String SIGNICAT_HEADER = "headerTextView";
	public static String SIGNICAT_BANKID_BTN = "//android.widget.Button[contains(@resource-id,'btnBankID')]";
	public static String CREATE_YOUR_PIN_BTN = "//android.widget.Button[contains(@resource-id,'btnMobileBankID')]";

	public static String TEXTBOX = "android.widget.EditText";
	public static String BUTTON = "android.widget.Button";

	public static String CREATE_YOUR_PIN_HEADING = "//android.widget.TextView[contains(@resource-id,'headerTextView')]";
	public static String PHONE_ICON_IMG = "//android.widget.ImageView[contains(@resource-id,'imgPhoneIcon')]";
	public static String PAD_DOTS_IMG = "//android.widget.ImageView[contains(@resource-id,'imgPadDots')]";
	public static String CREATE_YOUR_PIN_DESC = "//android.widget.TextView[contains(@resource-id,'bodytextTextView')]";
	public static String PRODUCT_LOGO = "//android.widget.ImageView[contains(@resource-id,'imgLogo')]";

	public static String POP_UP = "android.widget.FrameLayout";
	public static String ALERT_TITLE = "android:id/alertTitle";
	public static String CREATE_YOUR_PIN_TEXT = "//android.widget.EditText[contains(@resource-id,'txtCreatePIN')]";
	public static String CANCEL_BTN = "android:id/button2";
	public static String OK_BTN = "android:id/button1";

	public static String CREATE_UR_PIN_CANCEL_BTN = "//android.widget.TextView[contains(@resource-id,'action_call')]";
	public static String ENTER_PIN1_TXT = "//android.widget.EditText[contains(@resource-id,'txtpinOne')]";
	public static String ENTER_PIN2_TXT = "//android.widget.EditText[contains(@resource-id,'txtpinTwo')]";
	public static String ENTER_PIN3_TXT = "//android.widget.EditText[contains(@resource-id,'txtpinThree')]";
	public static String ENTER_PIN4_TXT = "//android.widget.EditText[contains(@resource-id,'txtpinFour')]";
	public static String LOADER = "//android.widget.ImageView[contains(@resource-id,'progSpent')]";

	public static String CONTACT_US = "//android.widget.TextView[contains(@resource-id,'lblContact')]";
	public static String CARD_SERVICE_LBL = "//android.widget.TextView[contains(@resource-id,'lblCardServiceTitle')]";
	public static String CARD_SERVICE_NUM = "//android.widget.TextView[contains(@resource-id,'lblCardServiceN')]";
	public static String BLOCK_CARD_LBL = "//android.widget.TextView[contains(@resource-id,'lblBlockCardTitle')]";
	public static String BLOCK_CARD_NUM = "//android.widget.TextView[contains(@resource-id,'lblBlockCardN')]";

	public static String LOGIN_BTN = "//android.widget.Button[contains(@resource-id,'btnLogin')]";

	public static String BUTTON_TEXT(String buttonText) {
		return "//android.widget.Button[@text='" + buttonText + "']";
	}

	public static String LABEL_TEXT(String labelText) {
		return "//android.widget.TextView[@text='" + labelText + "']";
	}

	public static String VIEW_TEXT(String viewText) {
		return "//android.view.View[@text='" + viewText + "']";
	}

	public static String IMAGE_TEXT(String imageText) {
		return "//android.widget.Image[@text='" + imageText + "']";
	}

	public static String SPINNER_TEXT(String spinnerText) {
		return "//android.widget.Spinner[@text='" + spinnerText + "']";
	}

	public static String EDIT_TEXT(String editText) {
		return "//android.widget.EditText[@text='" + editText + "']";
	}
	
	public static String EDIT_TEXT() {
		return "//android.widget.EditText";
	}

	public static final String ALLOW_BUITTON(String allow) {
		return "//android.widget.Button[@text='" + allow + "']";
	}

	/*
	 * Denmark
	 */

	// public static final String SIGNICAT_ACTIVATE_APP_BUTTON =
	// "dk.entercard.remember.debug:id/btnMobileBankID";
	public static final String LOADER_DK = "startup_spinner";
	public static final String SIGNICAT_TEXT = "Signicat";
	public static final String VALIDATE_OTP_PAGE_TEXT = "DanID Development Tools";
	public static final String VALIDATE_OTP_PAGE = "#sub_header";
	public static final String OTP_TABLE = "//div[@id='main_content']//table/tbody[2]/tr";

	public static final String OTP_CODE(String enterKey) {
		return "//android.widget.EditText[@text='" + enterKey
				+ "']/preceding-sibling::android.view.View";
	}
	
	public static final String ENTER_PASSWORD = "com.android.settings:id/password_entry";

}
