package pageobjects;

public class CLI_pageobject {

	/*
	 * NORWAY
	 */

	public static final String DESIRED_CREDIT_INCREASE = "//android.widget.TextView[contains(@resource-id,'lblTitle')]";
	public static final String CREDIT_AMOUNT_APPLIED = "//android.widget.TextView[contains(@resource-id,'lblCreditAmountApplied')]";
	public static final String SUBSTRACT_CREDIT_LIMIT = "//android.widget.Button[contains(@resource-id,'btnSubstractCreditLimit')]";
	public static final String PLUS_CREDIT_LIMIT = "//android.widget.Button[contains(@resource-id,'btnPlusCreditLimit')]";
	public static final String YEARLY_INCOME_LABEL = "//android.widget.TextView[contains(@resource-id,'lblYearlyIncome')]";
	public static final String YEARLY_INCOME_TEXT = "//android.widget.EditText[contains(@resource-id,'txtYearlyIncome')]";
	public static final String MORTGAGE_LABEL = "//android.widget.TextView[contains(@resource-id,'lblMortgageTitle')]";
	public static final String MORTGAGE_TEXT = "//android.widget.EditText[contains(@resource-id,'txtMortgage')]";
	public static final String OTHER_LOANS_LABEL = "//android.widget.TextView[contains(@resource-id,'lblOtherLoansTitle')]";
	public static final String OTHER_LOANS_TEXT = "//android.widget.EditText[contains(@resource-id,'txtOtherLoans')]";
	public static final String EMPLOYMENT_DROPDOWN = "//android.widget.TextView[contains(@resource-id,'lblEmploymentTitle')]";
	public static final String ARROW_IMAGE = "android.widget.ImageView";
	public static final String APPLY_CLI_BUTTON = "//android.widget.Button[contains(@resource-id,'btnApplyCLI')]";
	public static final String EMPLOYMENT_TYPE = "//android.widget.TextView[contains(@resource-id,'lblEmploymentName')]";
	public static final String SELECTED_EMPLOYMENT_TYPE = "//android.widget.TextView[contains(@resource-id,'lblEmploymentType')]";

	/*
	 * DENMARK
	 */
	public static final String MONTHLY_INCOME_TEXT = "//android.widget.EditText[contains(@resource-id,'txtMonthlyIncome')]";
	public static final String OCCUPANCY_LABEL = "//android.widget.TextView[contains(@resource-id,'lblOccupancyTitle')]";

	/*
	 * SWEDEN
	 */

	public static final String SUBSTRACT_ADULT = "//android.widget.Button[contains(@resource-id,'btnSubAdult')]";
	public static final String PLUS_ADULT = "//android.widget.Button[contains(@resource-id,'btnPlusAdult')]";
	public static final String SUBSTRACT_CHILD = "//android.widget.Button[contains(@resource-id,'btnSubChild')]";
	public static final String PLUS_CHILD = "//android.widget.Button[contains(@resource-id,'btnPlusChild')]";
	public static final String ADULT_LABEL = "//android.widget.TextView[contains(@resource-id,'lblAdult')]";
	public static final String CHILD_LABEL = "//android.widget.TextView[contains(@resource-id,'lblChild')]";
	public static final String CHILD_COUNT = "//android.widget.TextView[contains(@resource-id,'lblChildCount')]";
	public static final String ADULT_COUNT = "//android.widget.TextView[contains(@resource-id,'lblAdultCount')]";
	public static final String RESIDENCE_DROPDOWN = "//android.widget.TextView[contains(@resource-id,'lblResidenceTitle')]";
	public static final String SELECTED_RESIDENCE_TYPE = "//android.widget.TextView[contains(@resource-id,'lblResidenceType')]";
}
