package pageobjects;

public class Cards_pageobject {

	public final static String CLI_BUTTON = "//*[contains(@resource-id,'btnIncreaseCreditLimit')]";
	// public final static String CREDIT_LIMIT_LABEL =
	// "//*[contains(@resource-id,'lblCreditLimitTitle')]";
	public final static String CREDIT_LIMIT_AMT = "//*[contains(@resource-id,'lblCreditlimit') and not(contains(@resource-id,'Title'))]";
	// public final static String CARD_LABEl =
	// "//*[contains(@resource-id,'lblCardsTitle')]";
	public final static String CARD_HOLDER_NAME = "//*[contains(@resource-id,'titleTextView')]";
	public final static String CARD_NUMBER = "//*[contains(@resource-id,'lblDetail')]";
	public final static String CARDS = "//*[contains(@resource-id,'parentlinearlayout')]";

	public static final String USER_ICON = "//*[contains(@resource-id,'action_account')]";
	public static final String PRODUCT_LIST = "//*[contains(@resource-id,'parentlinearlayout')]";
	public static final String PRODUCT_NAME = "//*[contains(@resource-id,'lblCardName')]";
	public static final String PRODUCT_CARD_NUMBER = "//*[contains(@resource-id,'lblCardNumber')]";
	public static final String PRODUCT_SELECTED = "//*[contains(@resource-id,'imgCheck')]";
}
