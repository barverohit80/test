package pageobjects;

public class Moments_pageobject {

	public static final String LATEST_TRANSACTIONS = "//*[contains(@resource-id,'lblTransactions')]";
	public static final String LATEST_CURRENT_BALANCE = "//*[contains(@resource-id,'lblCurrentBalance')]";
	public static final String LATEST_AVAILABLE_CREDIT = "//*[contains(@resource-id,'lblAvailableCredit')]";
	public static final String SPENT_AMOUNT = "//*[contains(@resource-id,'lblSpent')]";
	public static final String OPENtoBUY_AMOUNT = "//*[contains(@resource-id,'lblOpenToBuy')]";
	public static final String PROGRESS_BAR = "//*[contains(@resource-id,'progSpentCash')]";

	public static String BACK_ACCId(String contentDesc) {
		return contentDesc;
	}

	public static final String VENDOR_ID = "//*[contains(@resource-id,'lblName')]";
	public static final String MOVEMENTS = "//*[contains(@resource-id,'llMainRow')]";

	public static final String TRANSACTION_DATE(String id) {
		return "//android.widget.LinearLayout[@content-desc='"
				+ id
				+ "' and contains(@resource-id,'llMainRow')]//android.widget.TextView[contains(@resource-id,'lblDate')]";
	}

	public static final String UISELECTOR_TRANSACTION_DATE(String id) {
		return "new UiSelector().description(\""
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblDate\"))";
	}

	public static final String TRANSACTION_VENDORID(String id) {
		return "//android.widget.LinearLayout[@content-desc='"
				+ id
				+ "' and contains(@resource-id,'llMainRow')]//android.widget.TextView[contains(@resource-id,'lblName')]";
	}

	public static final String UISELECTOR_TRANSACTION_VENDORID(String id) {
		return "new UiSelector().description(\""
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblName\"))";
	}

	public static final String TRANSACTION_COUNTRY_CURRENCY(String id) {
		return "//android.widget.LinearLayout[@content-desc='"
				+ id
				+ "' and contains(@resource-id,'llMainRow')]//android.widget.TextView[contains(@resource-id,'lblNameBox')]";
	}

	public static final String UISELECTOR_TRANSACTION_COUNTRY_CURRENCY(String id) {
		return "new UiSelector().description(\""
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblNameBox\"))";
	}

	public static final String TRANSACTION_AMT(String id) {
		return "//android.widget.LinearLayout[@content-desc='"
				+ id
				+ "' and contains(@resource-id,'llMainRow')]//android.widget.TextView[contains(@resource-id,'lblPrice')]";
	}

	public static final String UISELECTOR_TRANSACTION_AMT(String id) {
		return "new UiSelector().description(\""
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblPrice\"))";
	}

	public static final String LOADER_FOOTER = "//*[contains(@resource-id,'load_more_footer')]";
	public static final String LOADING_IN_PROGRESS = "//*[contains(@resource-id,'load_more_progressBar')]";
	public static final String TOOL_HOME_SCREEN = "//*[contains(@resource-id,'toolbarHomeScreen')]";
	public static final String TABS = "//*[contains(@resource-id,'tabs')]";
}
