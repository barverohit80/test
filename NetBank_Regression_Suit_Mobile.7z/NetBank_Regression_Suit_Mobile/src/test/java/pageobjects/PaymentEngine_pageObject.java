package pageobjects;

import java.util.ArrayList;
import java.util.HashMap;

import seleniumCore.SharedDriver;

public class PaymentEngine_pageObject {
	public static ArrayList<String> MESSAGE;
	public static String HEADING1;
	private static HashMap<String, String> regionLables = SharedDriver.labels;
	// NORWAY MOBILE

	public final static String FUND_TRANSFER_BUTTON = "id/btnFundsTransfer";
	public final static String LINEAR_LAYOUT = "android.widget.LinearLayout";
	public final static String MESSAGE_BOX_ID = "id/txtMessage";
	public final static String RECEIVER_NAME_ID = "id/txtReceiversName";
	public final static String BANK_NAME_CLASS = "android.widget.CheckedTextView";

	public final static String PE_HEADING_TEXT = "//android.widget.TextView[contains(@resource-id,'lblHeadingText')]";
	public final static String RECEIVER_NAME_LABEL = "//android.widget.TextView[contains(@resource-id,'lblReceiverName')]";
	public final static String RECEIVER_NAME_TEXT = "//android.widget.EditText[contains(@resource-id,'txtReceiversName')]";
	public final static String ACCOUNT_NUMBER_LABEL = "//android.widget.TextView[contains(@resource-id,'lblAccountNumer')]";
	public final static String ACCOUNT_NUMBER_TEXT = "//android.widget.EditText[contains(@resource-id,'txtAccountNumber')]";
	public final static String AMOUNT_LABEL = "//android.widget.TextView[contains(@resource-id,'lblAmount')]";
	public final static String AMOUNT_ONE_TEXT = "//android.widget.EditText[contains(@resource-id,'txtAmountOne')]";
	public final static String AMOUNT_FORMATTER = "//android.widget.TextView[contains(@resource-id,'lblAmountFormatter')]";
	public final static String AMOUNT_TWO_TEXT = "//android.widget.EditText[contains(@resource-id,'txtAmountTwo')]";
	public final static String MESSAGE_RADIO_BUTTON = "//*[contains(@resource-id,'radMessage')]";
	public final static String KID_RADIO_BUTTON = "//*[contains(@resource-id,'radKID')]";
	public final static String RADIO_BUTTONS = "android.widget.RadioButton";
	public final static String MESSAGE_TEXT = "//android.widget.EditText[contains(@resource-id,'txtMessage')]";

	public final static String ALERT_MESSAGE(String str) {
		String locator = null;
		if (!str.contains("TnC")) {
			locator = "//*[@resource-id='android:id/message']";
		} else {
			locator = "//*[contains(@resource-id,'lblSingleTitle')]";
		}
		return locator;
	}

	public final static String ALERT_HEADING = "//*[@resource-id='android:id/alertTitle']";

	public static void VALIDATIONMESSAGE(String message) {
		MESSAGE = new ArrayList<String>();
		if (message.equalsIgnoreCase("CLI")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("encap_something_went_wrong") + "']";
			MESSAGE.add(regionLables.get("encap_error"));
			// MESSAGE.add(regionLables.get("CLI_APPLICATION_DECLINED"));
			// MESSAGE.add(regionLables.get("CLI_APPLICATION_BEING_PROCEED"));
			// MESSAGE.add(regionLables.get("CLI_SUCCESS_POPUP"));

		} else if (message.contains("_positive")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("encap_something_went_wrong") + "']";
			MESSAGE.add(regionLables
					.get("ft_reg_bill_internal_service_failure"));
		} else if (message.contains("Less_Than_1")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("alert_title") + "']";
			MESSAGE.add(regionLables.get("amount_incorrect"));
		} else if (message.contains("INSUFFICIENT_FUND")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("alert_title") + "']";
			MESSAGE.add(regionLables.get("amount_cannot_be_higher_than_otb"));
		} else if (message.contains("LIMIT")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("alert_title") + "']";
			MESSAGE.add(regionLables
					.get("ft_reg_bill_internal_service_failure"));
		} else if (message.contains("TnC")) {
			HEADING1 = "//android.widget.TextView[@text='"
					+ regionLables.get("accept_terms_and_condition") + "']";
			MESSAGE.add(regionLables.get("accept_terms_condition_cli"));
		}
	}

	/*
	 * DENMARK
	 */

	public static final String INTERBANK_TRANSFER = "//android.widget.TextView[contains(@resource-id,'lblTransferNemconto')]";

	/*
	 * SWEDEN
	 */

	public final static String RECEIVER_BANK_LABEL = "//android.widget.TextView[contains(@resource-id,'lblReceiversBankName')]";
	public final static String RECEIVER_BANK_DROPDOWN = "//android.widget.Spinner[contains(@resource-id,'spnReceiversBankName')]";
	public final static String CLEARING_NUMBER_LABEL = "//android.widget.TextView[contains(@resource-id,'lblClearingNumber')]";
	public final static String CLEARING_NUMBER_TEXT = "//android.widget.EditText[contains(@resource-id,'txtClearingNumber')]";

	public static String RECEIVER_BANK_NAME(String bankName) {
		return "//android.widget.CheckedTextView[@text='" + bankName + "']";
	}

	public final static String BANK_NAME = "//android.widget.CheckedTextView";
	public final static String SELECTED_BANK_NAME = "//android.widget.TextView[contains(@resource-id,'lblSingleTitle')]";
}
