package pageobjects;

public class Invoices_pageobject {

	public static final String CARD_VIEW_INVOICES = "//*[contains(@resource-id,'cardviewInvoice')]";
	
	public static final String UISELECTOR_MONTH(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblInvoiceMonth\"))";
	}

	public static final String UISELECTOR_TOTAL_BALANCE_LBL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblTitleTotalBalance\"))";
	}

	public static final String UISELECTOR_MINIMUM_TO_PAY_LBL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblTitleMinimumToPay\"))";
	}

	public static final String UISELECTOR_CUT_OFF_DATE_LBL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblTitleCutOffDate\"))";
	}

	public static final String UISELECTOR_DUE_DATE_LBL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblTitleDueDate\"))";
	}

	public static final String UISELECTOR_TOTAL_BALANCE_VAL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblTotalBalance\"))";
	}

	public static final String UISELECTOR_MINIMUM_TO_PAY_VAL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblMinimumToPay\"))";
	}

	public static final String UISELECTOR_CUT_OFF_DATE_VAL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblCutOffdate\"))";
	}

	public static final String UISELECTOR_DUE_DATE_VAL(String id) {
		return "new UiSelector().description(\"cv-"
				+ id
				+ "\").childSelector(new UiSelector().resourceIdMatches(\".*:id/lblDueDate\"))";
	}

	public static final String TOOLBAR_INVOICE_DETAILS = "//*[contains(@resource-id,'toolbarInvoiceDetails')]";
}
