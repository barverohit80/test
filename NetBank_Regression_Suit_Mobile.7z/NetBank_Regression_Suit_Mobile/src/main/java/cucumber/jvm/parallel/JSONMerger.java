package cucumber.jvm.parallel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;

public class JSONMerger {

	public static void main(String[] args) {
		// merging two files

		// Mereged json files save in cucumber.json file
		String mergedFilePath = System.getProperty("user.dir")
				+ "/target/cucumber.json";

		File mergedFile = new File(mergedFilePath);

		// removed Start and last square bracket for all files for (int i =
		for (int i = 0; i < findAllJSONfiles().length; i++) {
			if (!findAllJSONfiles()[i].isFile()) {
				System.out.println("is not an existing file");
			}

			String str = findAllJSONfiles()[i] + "";
			removeLineFromFile(str, "[");
			removeLineFromFile(str, "]");
		}

		// appended string at the end of the files except last file for (int
		for (int i = 0; i < findAllJSONfiles().length - 1; i++) {
			if (!findAllJSONfiles()[i].isFile()) {
				System.out.println("is not an existing file");
			}
			appendAtTheEnd(findAllJSONfiles()[i], ",");
		}

		// merged files here
		mergeFiles(findAllJSONfiles(), mergedFile);

		// appended [ at the start of the files except last file
		appendAtTheStart(mergedFile, "[");

		// appended ] at the end of the files except last file
		appendAtTheEnd(mergedFile, "]");

		// find all json files in target folder
		// findAllJSONfiles();
	}

	public static void removeLineFromFile(String file, String lineToRemove) {

		try {
			File inFile = new File(file);
			if (!inFile.isFile()) {
				System.out.println("Parameter is not an existing file");
				return;
			}
			// Construct the new file that will later be renamed to the original
			// filename.
			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");
			BufferedReader br = new BufferedReader(new FileReader(file));
			PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
			String line;
			// Read from the original file and write to the new
			// unless content matches data to be removed.
			while ((line = br.readLine()) != null) {
				if (!line.equals(lineToRemove)) {
					pw.println(line);
					pw.flush();
				}
			}
			pw.close();
			br.close();

			// Delete the original file
			if (!inFile.delete()) {
				System.out.println("Could not delete file");
				return;
			}
			// Rename the new file to the filename the original file had.
			if (!tempFile.renameTo(inFile))
				System.out.println("Could not rename file");

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static void mergeFiles(File[] files, File mergedFile) {

		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			fstream = new FileWriter(mergedFile, true);
			out = new BufferedWriter(fstream);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		for (File f : files) {
			System.out.println("merging: " + f.getName());
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				BufferedReader in = new BufferedReader(new InputStreamReader(
						fis));

				String aLine;
				while ((aLine = in.readLine()) != null) {
					out.write(aLine);
					out.newLine();
				}

				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void appendAtTheEnd(File path, String str) {
		try {

			FileWriter fstream = new FileWriter(path, true);
			BufferedWriter fbw = new BufferedWriter(fstream);
			fbw.write(str);
			fbw.newLine();
			fbw.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public static void appendAtTheStart(File path, String str) {
		try {
			RandomAccessFile f = new RandomAccessFile(path, "rw");
			f.seek(0); // to the beginning
			f.write(str.getBytes());
			f.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public static File[] findAllJSONfiles() {
		File f = new File(System.getProperty("user.dir") + "/target");
		File[] matchingFiles = f.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				if (name.endsWith(".json") && !name.contains("cucumber")) {
					return name.endsWith(".json");
				}
				return false;
			}
		});
		return matchingFiles;
	}
}
